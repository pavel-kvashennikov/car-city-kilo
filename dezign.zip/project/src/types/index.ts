export interface CarBrand {
  id: number;
  name: string;
  slug: string;
  logo?: string;
  country?: string;
  is_popular: boolean;
}

export interface CarModel {
  id: number;
  brand_id: number;
  name: string;
  slug: string;
}

export interface CarGeneration {
  id: number;
  model_id: number;
  name: string;
  year_from: number;
  year_to: number | null;
}

export interface Vehicle {
  id: number;
  uuid: string;
  slug: string;
  brand: CarBrand;
  model: CarModel;
  generation?: CarGeneration;
  year: number;
  mileage: number;
  color: string;
  engine_type: 'petrol' | 'diesel' | 'hybrid' | 'electric' | 'gas';
  engine_volume: number;
  engine_power: number;
  transmission: 'manual' | 'automatic' | 'robot' | 'cvt';
  drive_type: 'fwd' | 'rwd' | 'awd' | '4wd';
  body_type: string;
  price: number;
  credit_price_from?: number;
  condition: 'new' | 'used' | 'damaged';
  legal_status: string;
  description: string;
  photos: string[];
  cover_photo: string;
  dealer: CompanyPreview;
  allows_test_drive: boolean;
  allows_credit: boolean;
  allows_trade_in: boolean;
  status: string;
  views_count: number;
  favorites_count: number;
  published_at: string;
  equipment: Record<string, string[]>;
}

export interface Product {
  id: number;
  uuid: string;
  slug: string;
  name: string;
  article_number: string;
  oem_number?: string;
  cross_numbers: string[];
  brand: string;
  category: PartCategory;
  condition: 'new' | 'used' | 'refurbished';
  part_type: 'original' | 'oem' | 'aftermarket';
  price_retail: number;
  price_wholesale?: number;
  wholesale_min_qty: number;
  in_stock: boolean;
  quantity: number;
  description: string;
  photos: string[];
  cover_photo: string;
  applicability: ProductApplicability[];
  store: CompanyPreview;
  attributes: Record<string, string>;
}

export interface ProductApplicability {
  brand: string;
  model: string;
  year_from: number;
  year_to: number | null;
  engine_codes?: string;
}

export interface PartCategory {
  id: number;
  name: string;
  slug: string;
  parent_id?: number;
  icon?: string;
  children?: PartCategory[];
}

export interface ServiceItem {
  id: number;
  uuid: string;
  name: string;
  description: string;
  category: ServiceCategory;
  price_type: 'fixed' | 'hourly' | 'range' | 'by_agreement';
  price_fixed?: number;
  price_min?: number;
  price_max?: number;
  labor_rate?: number;
  labor_hours?: number;
  duration_minutes: number;
  applicable_car_types: string[];
}

export interface ServiceCategory {
  id: number;
  name: string;
  slug: string;
  icon?: string;
}

export interface ServiceProfile {
  id: number;
  uuid: string;
  slug: string;
  company: CompanyPreview;
  name: string;
  description: string;
  specializations: string[];
  car_types: string[];
  working_hours: Record<string, { open: string; close: string; is_day_off: boolean }>;
  slot_duration_minutes: number;
  services: ServiceItem[];
  masters: ServiceMaster[];
  cover_photo?: string;
  photos: string[];
  rating: number;
  reviews_count: number;
}

export interface ServiceMaster {
  id: number;
  name: string;
  specialization: string;
  photo?: string;
  rating: number;
}

export interface TimeSlot {
  id: number;
  date: string;
  start_time: string;
  end_time: string;
  status: 'available' | 'booked' | 'blocked';
  master_id?: number;
}

export interface Appointment {
  id: number;
  uuid: string;
  service_profile_id: number;
  time_slot: TimeSlot;
  master?: ServiceMaster;
  service_items: ServiceItem[];
  car_brand: string;
  car_model: string;
  car_year: number;
  contact_name: string;
  contact_phone: string;
  estimated_cost: number;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
}

export interface CompanyPreview {
  id: number;
  name: string;
  slug: string;
  logo?: string;
  profile_types: string[];
  location?: MarketLocation;
}

export interface Company {
  id: number;
  uuid: string;
  slug: string;
  name: string;
  legal_name?: string;
  inn?: string;
  description: string;
  logo?: string;
  website?: string;
  phone: string;
  email: string;
  status: 'pending' | 'active' | 'suspended';
  profile_types: string[];
  location?: MarketLocation;
  rating: number;
  reviews_count: number;
  dealer_profile?: DealerProfilePreview;
  parts_profile?: PartsProfilePreview;
  service_profile?: ServiceProfilePreview;
}

export interface DealerProfilePreview {
  vehicles_count: number;
  allows_test_drive: boolean;
  allows_credit: boolean;
}

export interface PartsProfilePreview {
  products_count: number;
  min_order_amount: number;
}

export interface ServiceProfilePreview {
  services_count: number;
  masters_count: number;
}

export interface MarketZone {
  id: number;
  name: string;
  color: string;
  description?: string;
}

export interface MarketLocation {
  id: number;
  zone: MarketZone;
  company?: CompanyPreview;
  identifier: string;
  location_type: 'pavilion' | 'box' | 'outdoor_spot';
  coordinates: { x: number; y: number; width: number; height: number };
  status: 'available' | 'occupied' | 'reserved';
}

export interface CartItem {
  id: number;
  itemable_type: 'Product' | 'Appointment';
  itemable_id: number;
  quantity: number;
  unit_price: number;
  snapshot: {
    name: string;
    image?: string;
    article?: string;
  };
  meta?: Record<string, unknown>;
}

export interface Order {
  id: number;
  uuid: string;
  order_number: string;
  items: OrderItem[];
  total_amount: number;
  status: 'pending' | 'confirmed' | 'processing' | 'ready' | 'completed' | 'cancelled';
  created_at: string;
}

export interface OrderItem {
  id: number;
  itemable_type: 'Product' | 'Appointment';
  name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
  status: string;
}

export interface DealerLead {
  id: number;
  uuid: string;
  lead_type: 'test_drive' | 'credit' | 'trade_in' | 'callback';
  vehicle?: Vehicle;
  contact_name: string;
  contact_phone: string;
  status: 'new' | 'in_progress' | 'completed' | 'cancelled';
  preferred_datetime?: string;
  message?: string;
  created_at: string;
}

export interface Plan {
  id: number;
  name: string;
  slug: string;
  price_monthly: number;
  price_yearly?: number;
  features: Record<string, unknown>;
  allowed_profiles: string[];
}

export interface DashboardStats {
  vehicles_count: number;
  active_vehicles: number;
  leads_count: number;
  new_leads_count: number;
  products_count: number;
  orders_count: number;
  appointments_count: number;
  revenue: number;
  views_today: number;
}
