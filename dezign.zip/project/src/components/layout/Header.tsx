import { Link, useLocation } from 'react-router-dom';
import { Car, Wrench, Package, Map, ShoppingCart, User, Menu, X, Sparkles } from 'lucide-react';
import { useState, useEffect } from 'react';

const navItems = [
  { to: '/cars', label: 'Автомобили', icon: Car },
  { to: '/parts', label: 'Запчасти', icon: Package },
  { to: '/services', label: 'Сервисы', icon: Wrench },
  { to: '/companies', label: 'Компании', icon: User },
  { to: '/map', label: 'Карта', icon: Map },
];

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white/80 backdrop-blur-2xl border-b border-neutral-200/50 shadow-[0_4px_30px_rgba(0,0,0,0.03)]'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <div className="container-app">
        <div className="flex items-center justify-between h-18 py-4">
          <Link to="/" className="flex items-center gap-3 shrink-0 group">
            <div className="relative">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary-500 via-primary-600 to-accent-500 flex items-center justify-center shadow-lg shadow-primary-500/25 group-hover:shadow-xl group-hover:shadow-primary-500/30 transition-all duration-300 group-hover:scale-105">
                <Car className="w-5.5 h-5.5 text-white" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-accent-400 border-2 border-white flex items-center justify-center">
                <Sparkles className="w-2 h-2 text-white" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold bg-gradient-to-r from-neutral-900 via-neutral-800 to-neutral-600 bg-clip-text text-transparent tracking-tight">AutoMarket</span>
              <span className="text-[10px] text-neutral-400 font-medium -mt-0.5 tracking-wide">AUTOMOTIVE PLATFORM</span>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center gap-1 bg-neutral-100/60 backdrop-blur-sm rounded-2xl p-1">
            {navItems.map((item) => {
              const active = location.pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`relative flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                    active
                      ? 'text-primary-700'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  {active && (
                    <span className="absolute inset-0 bg-white rounded-xl shadow-sm" />
                  )}
                  <item.icon className={`w-4 h-4 relative z-10 transition-colors ${active ? 'text-primary-600' : ''}`} />
                  <span className="relative z-10">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <Link to="/cart" className="btn-ghost btn-icon relative group">
              <ShoppingCart className="w-5 h-5 group-hover:text-primary-600 transition-colors" />
              <span className="absolute -top-0.5 -right-0.5 w-5 h-5 rounded-full bg-gradient-to-br from-primary-500 to-accent-400 text-white text-[10px] font-bold flex items-center justify-center shadow-lg shadow-primary-500/20 animate-pulse-slow">3</span>
            </Link>

            <div className="hidden sm:flex items-center gap-2 ml-2">
              <Link to="/cabinet" className="btn-secondary btn-sm">
                Кабинет
              </Link>
              <Link to="/login" className="btn-primary btn-sm">
                Войти
              </Link>
            </div>

            <button onClick={() => setMobileOpen(!mobileOpen)} className="btn-ghost btn-icon lg:hidden">
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {mobileOpen && (
          <div className="lg:hidden border-t border-neutral-200/50 py-4 animate-slide-down bg-white/95 backdrop-blur-xl rounded-b-2xl shadow-lg">
            <nav className="flex flex-col gap-1">
              {navItems.map((item) => {
                const active = location.pathname.startsWith(item.to);
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                      active ? 'text-primary-700 bg-primary-50' : 'text-neutral-600 hover:bg-neutral-50'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </Link>
                );
              })}
              <div className="flex gap-2 mt-4 pt-4 border-t border-neutral-100 px-1">
                <Link to="/cabinet" className="btn-secondary btn-sm flex-1" onClick={() => setMobileOpen(false)}>Кабинет</Link>
                <Link to="/login" className="btn-primary btn-sm flex-1" onClick={() => setMobileOpen(false)}>Войти</Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
