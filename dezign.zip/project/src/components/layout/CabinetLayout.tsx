import { Link, Outlet, useLocation } from 'react-router-dom';
import { Car, Package, Wrench, BarChart3, Users, Settings, CreditCard, LayoutDashboard, ChevronRight, Bell, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

const sidebarItems = [
  { to: '/cabinet', label: 'Дашборд', icon: LayoutDashboard, end: true },
  { to: '/cabinet/company', label: 'Компания', icon: Settings },
  { to: '/cabinet/staff', label: 'Сотрудники', icon: Users },
  { to: '/cabinet/dealer', label: 'Автомобили', icon: Car },
  { to: '/cabinet/dealer/leads', label: 'Заявки', icon: Bell },
  { to: '/cabinet/parts', label: 'Запчасти', icon: Package },
  { to: '/cabinet/parts/orders', label: 'Заказы', icon: CreditCard },
  { to: '/cabinet/service', label: 'Сервис', icon: Wrench },
  { to: '/cabinet/service/schedule', label: 'Расписание', icon: BarChart3 },
  { to: '/cabinet/billing', label: 'Биллинг', icon: CreditCard },
  { to: '/cabinet/analytics', label: 'Аналитика', icon: BarChart3 },
];

export default function CabinetLayout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isActive = (to: string, end?: boolean) => {
    if (end) return location.pathname === to;
    return location.pathname.startsWith(to);
  };

  const sidebar = (
    <nav className="flex flex-col gap-1 p-3">
      {sidebarItems.map(item => {
        const active = isActive(item.to, item.end);
        return (
          <Link
            key={item.to}
            to={item.to}
            onClick={() => setSidebarOpen(false)}
            className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              active
                ? 'bg-primary-50 text-primary-700'
                : 'text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900'
            }`}
          >
            <item.icon className="w-4 h-4" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <div className="min-h-screen bg-neutral-75 flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col bg-white border-r border-neutral-150 shrink-0">
        <div className="h-16 flex items-center px-5 border-b border-neutral-100">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
              <Car className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-neutral-900">AutoMarket</span>
          </Link>
        </div>
        <div className="flex-1 overflow-y-auto py-2">
          {sidebar}
        </div>
        <div className="p-3 border-t border-neutral-100">
          <Link to="/" className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-neutral-500 hover:text-neutral-700 hover:bg-neutral-50 transition-colors">
            <LogOut className="w-4 h-4" />
            На сайт
          </Link>
        </div>
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setSidebarOpen(false)} />
          <aside className="relative w-64 h-full bg-white shadow-elevated animate-slide-right">
            <div className="h-16 flex items-center justify-between px-5 border-b border-neutral-100">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary-600 flex items-center justify-center">
                  <Car className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-neutral-900">AutoMarket</span>
              </Link>
              <button onClick={() => setSidebarOpen(false)} className="btn-ghost btn-icon">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto py-2">
              {sidebar}
            </div>
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-neutral-150 flex items-center justify-between px-4 lg:px-6 shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="btn-ghost btn-icon lg:hidden">
              <Menu className="w-5 h-5" />
            </button>
            <nav className="flex items-center gap-1 text-sm text-neutral-500">
              <Link to="/cabinet" className="hover:text-neutral-700 transition-colors">Кабинет</Link>
              <ChevronRight className="w-3.5 h-3.5" />
              <span className="text-neutral-900 font-medium">Дашборд</span>
            </nav>
          </div>
          <div className="flex items-center gap-2">
            <button className="btn-ghost btn-icon relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-0.5 right-0.5 w-2 h-2 rounded-full bg-error-500" />
            </button>
            <div className="flex items-center gap-2 ml-2 pl-2 border-l border-neutral-200">
              <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center">
                <span className="text-xs font-semibold text-primary-700">АП</span>
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-medium text-neutral-900">АвтоПрестиж</p>
                <p className="text-xs text-neutral-500">Владелец</p>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
