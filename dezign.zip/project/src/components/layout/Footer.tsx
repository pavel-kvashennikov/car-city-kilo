import { Link } from 'react-router-dom';
import { Car, Phone, Mail, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-neutral-900 text-neutral-300 mt-auto">
      <div className="container-app py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-lg bg-primary-600 flex items-center justify-center">
                <Car className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold text-white">AutoMarket</span>
            </div>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Единый портал городского авторынка. Автомобили, запчасти, автосервисы — всё в одном месте.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Каталог</h4>
            <div className="flex flex-col gap-2.5">
              <Link to="/cars" className="text-sm text-neutral-400 hover:text-white transition-colors">Автомобили</Link>
              <Link to="/parts" className="text-sm text-neutral-400 hover:text-white transition-colors">Запчасти</Link>
              <Link to="/services" className="text-sm text-neutral-400 hover:text-white transition-colors">Автосервисы</Link>
              <Link to="/companies" className="text-sm text-neutral-400 hover:text-white transition-colors">Компании</Link>
              <Link to="/map" className="text-sm text-neutral-400 hover:text-white transition-colors">Карта рынка</Link>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Резидентам</h4>
            <div className="flex flex-col gap-2.5">
              <Link to="/register" className="text-sm text-neutral-400 hover:text-white transition-colors">Регистрация компании</Link>
              <Link to="/cabinet" className="text-sm text-neutral-400 hover:text-white transition-colors">Личный кабинет</Link>
              <Link to="/pricing" className="text-sm text-neutral-400 hover:text-white transition-colors">Тарифы</Link>
              <Link to="/docs" className="text-sm text-neutral-400 hover:text-white transition-colors">Документация API</Link>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Контакты</h4>
            <div className="flex flex-col gap-3">
              <a href="tel:+74951234567" className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors">
                <Phone className="w-4 h-4" />
                +7 (495) 123-45-67
              </a>
              <a href="mailto:info@automarket.ru" className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors">
                <Mail className="w-4 h-4" />
                info@automarket.ru
              </a>
              <div className="flex items-start gap-2 text-sm text-neutral-400">
                <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
                г. Москва, авторынок, Павильон А, офис 1
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-neutral-500">&copy; 2025 AutoMarket. Все права защищены.</p>
          <div className="flex gap-4">
            <Link to="/privacy" className="text-xs text-neutral-500 hover:text-neutral-300 transition-colors">Политика конфиденциальности</Link>
            <Link to="/terms" className="text-xs text-neutral-500 hover:text-neutral-300 transition-colors">Пользовательское соглашение</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
