import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Search,
  SlidersHorizontal,
  Heart,
  Fuel,
  Gauge,
  Settings2,
  ChevronDown,
  X,
  Car,
} from 'lucide-react';
import { vehicles, carBrands } from '../../data';
import type { Vehicle } from '../../types';

type SortOption = 'date' | 'price-asc' | 'price-desc' | 'mileage';

interface Filters {
  brand: string;
  yearFrom: number | '';
  yearTo: number | '';
  priceFrom: number | '';
  priceTo: number | '';
  mileageFrom: number | '';
  mileageTo: number | '';
  transmission: string[];
  engineType: string[];
  condition: 'all' | 'new' | 'used';
}

const transmissionLabels: Record<string, string> = {
  manual: 'МКПП',
  automatic: 'АКПП',
  robot: 'Робот',
  cvt: 'Вариатор',
};

const engineTypeLabels: Record<string, string> = {
  petrol: 'Бензин',
  diesel: 'Дизель',
  hybrid: 'Гибрид',
  electric: 'Электро',
  gas: 'Газ',
};

const conditionLabels: Record<string, string> = {
  new: 'Новый',
  used: 'С пробегом',
};

const driveLabels: Record<string, string> = {
  fwd: 'Передний',
  rwd: 'Задний',
  awd: 'Полный',
  '4wd': '4WD',
};

const bodyTypeLabels: Record<string, string> = {
  sedan: 'Седан',
  suv: 'Внедорожник',
  hatchback: 'Хэтчбек',
  coupe: 'Купе',
  wagon: 'Универсал',
  minivan: 'Минивэн',
  pickup: 'Пикап',
};

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

function formatMileage(mileage: number) {
  return new Intl.NumberFormat('ru-RU').format(mileage);
}

export default function CarsIndex() {
  const [sort, setSort] = useState<SortOption>('date');
  const [showFiltersDrawer, setShowFiltersDrawer] = useState(false);
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  const [filters, setFilters] = useState<Filters>({
    brand: '',
    yearFrom: '',
    yearTo: '',
    priceFrom: '',
    priceTo: '',
    mileageFrom: '',
    mileageTo: '',
    transmission: [],
    engineType: [],
    condition: 'all',
  });

  const filteredAndSortedVehicles = useMemo(() => {
    let result = [...vehicles];

    if (filters.brand) {
      result = result.filter((v) => v.brand.name === filters.brand);
    }
    if (filters.yearFrom) result = result.filter((v) => v.year >= (filters.yearFrom as number));
    if (filters.yearTo) result = result.filter((v) => v.year <= (filters.yearTo as number));
    if (filters.priceFrom) result = result.filter((v) => v.price >= (filters.priceFrom as number));
    if (filters.priceTo) result = result.filter((v) => v.price <= (filters.priceTo as number));
    if (filters.mileageFrom) result = result.filter((v) => v.mileage >= (filters.mileageFrom as number));
    if (filters.mileageTo) result = result.filter((v) => v.mileage <= (filters.mileageTo as number));
    if (filters.transmission.length > 0) {
      result = result.filter((v) => filters.transmission.includes(v.transmission));
    }
    if (filters.engineType.length > 0) {
      result = result.filter((v) => filters.engineType.includes(v.engine_type));
    }
    if (filters.condition !== 'all') {
      result = result.filter((v) => v.condition === filters.condition);
    }

    result.sort((a, b) => {
      switch (sort) {
        case 'date':
          return new Date(b.published_at).getTime() - new Date(a.published_at).getTime();
        case 'price-asc':
          return a.price - b.price;
        case 'price-desc':
          return b.price - a.price;
        case 'mileage':
          return a.mileage - b.mileage;
        default:
          return 0;
      }
    });

    return result;
  }, [filters, sort]);

  const updateFilter = (key: keyof Filters, value: unknown) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const toggleArrayFilter = (key: 'transmission' | 'engineType', value: string) => {
    setFilters((prev) => {
      const arr = prev[key] as string[];
      return {
        ...prev,
        [key]: arr.includes(value) ? arr.filter((v) => v !== value) : [...arr, value],
      };
    });
  };

  const resetFilters = () => {
    setFilters({
      brand: '',
      yearFrom: '',
      yearTo: '',
      priceFrom: '',
      priceTo: '',
      mileageFrom: '',
      mileageTo: '',
      transmission: [],
      engineType: [],
      condition: 'all',
    });
  };

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const FilterContent = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Марка</label>
        <select
          value={filters.brand}
          onChange={(e) => updateFilter('brand', e.target.value)}
          className="select"
        >
          <option value="">Все марки</option>
          {carBrands.map((b) => (
            <option key={b.id} value={b.name}>
              {b.name}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Год выпуска</label>
        <div className="flex gap-2">
          <input
            type="number"
            placeholder="От"
            value={filters.yearFrom}
            onChange={(e) => updateFilter('yearFrom', e.target.value ? parseInt(e.target.value) : '')}
            className="input"
          />
          <input
            type="number"
            placeholder="До"
            value={filters.yearTo}
            onChange={(e) => updateFilter('yearTo', e.target.value ? parseInt(e.target.value) : '')}
            className="input"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Цена, ₽</label>
        <div className="flex gap-2">
          <input
            type="number"
            placeholder="От"
            value={filters.priceFrom}
            onChange={(e) => updateFilter('priceFrom', e.target.value ? parseInt(e.target.value) : '')}
            className="input"
          />
          <input
            type="number"
            placeholder="До"
            value={filters.priceTo}
            onChange={(e) => updateFilter('priceTo', e.target.value ? parseInt(e.target.value) : '')}
            className="input"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Пробег, км</label>
        <div className="flex gap-2">
          <input
            type="number"
            placeholder="От"
            value={filters.mileageFrom}
            onChange={(e) => updateFilter('mileageFrom', e.target.value ? parseInt(e.target.value) : '')}
            className="input"
          />
          <input
            type="number"
            placeholder="До"
            value={filters.mileageTo}
            onChange={(e) => updateFilter('mileageTo', e.target.value ? parseInt(e.target.value) : '')}
            className="input"
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Коробка передач</label>
        <div className="space-y-2">
          {Object.entries(transmissionLabels).map(([key, label]) => (
            <label key={key} className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.transmission.includes(key)}
                onChange={() => toggleArrayFilter('transmission', key)}
                className="w-4 h-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="text-sm text-neutral-700">{label}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Тип двигателя</label>
        <div className="space-y-2">
          {Object.entries(engineTypeLabels).map(([key, label]) => (
            <label key={key} className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.engineType.includes(key)}
                onChange={() => toggleArrayFilter('engineType', key)}
                className="w-4 h-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="text-sm text-neutral-700">{label}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-neutral-900 mb-2">Состояние</label>
        <div className="space-y-2">
          {[
            { value: 'all', label: 'Все' },
            { value: 'new', label: 'Новый' },
            { value: 'used', label: 'С пробегом' },
          ].map((opt) => (
            <label key={opt.value} className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="radio"
                name="condition"
                value={opt.value}
                checked={filters.condition === opt.value}
                onChange={() => updateFilter('condition', opt.value)}
                className="w-4 h-4 text-primary-600 focus:ring-primary-500"
              />
              <span className="text-sm text-neutral-700">{opt.label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="flex gap-2 pt-2">
        <button onClick={() => setShowFiltersDrawer(false)} className="btn-primary flex-1">
          Показать
        </button>
        <button onClick={resetFilters} className="btn-secondary flex-1">
          Сбросить
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Hero */}
      <div className="bg-gradient-to-br from-primary-700 via-primary-600 to-primary-800 text-white py-10 lg:py-14">
        <div className="container-app">
          <div className="flex items-center gap-3 mb-3">
            <Car className="w-8 h-8 text-primary-200" />
            <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">Автомобили</h1>
          </div>
          <p className="text-primary-100 text-lg">
            {filteredAndSortedVehicles.length} автомобилей в наличии от проверенных дилеров
          </p>
        </div>
      </div>

      <div className="container-app py-6 lg:py-8">
        <div className="flex gap-6 lg:gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className="hidden lg:block w-72 shrink-0">
            <div className="card p-5 sticky top-20">
              <h2 className="text-base font-bold text-neutral-900 mb-5">Фильтры</h2>
              <FilterContent />
            </div>
          </aside>

          {/* Main */}
          <div className="flex-1 min-w-0">
            {/* Mobile filter button */}
            <div className="lg:hidden mb-4">
              <button
                onClick={() => setShowFiltersDrawer(true)}
                className="btn-primary w-full"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Фильтры
              </button>
            </div>

            {/* Sort bar */}
            <div className="flex items-center justify-between gap-4 mb-5">
              <p className="text-sm text-neutral-500">
                Найдено:{' '}
                <span className="font-semibold text-neutral-900">
                  {filteredAndSortedVehicles.length}
                </span>
              </p>
              <div className="relative">
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value as SortOption)}
                  className="select w-auto pr-10"
                >
                  <option value="date">По дате</option>
                  <option value="price-asc">Сначала дешевле</option>
                  <option value="price-desc">Сначала дороже</option>
                  <option value="mileage">По пробегу</option>
                </select>
              </div>
            </div>

            {/* Vehicle Grid */}
            {filteredAndSortedVehicles.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {filteredAndSortedVehicles.map((vehicle) => (
                  <VehicleCard
                    key={vehicle.id}
                    vehicle={vehicle}
                    isFavorite={favorites.has(vehicle.id)}
                    onToggleFavorite={() => toggleFavorite(vehicle.id)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Car className="w-16 h-16 text-neutral-300 mx-auto mb-4" />
                <p className="text-neutral-500 text-lg font-medium">Автомобили не найдены</p>
                <p className="text-neutral-400 text-sm mt-1">Попробуйте изменить параметры фильтров</p>
                <button onClick={resetFilters} className="btn-primary mt-4">
                  Сбросить фильтры
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {showFiltersDrawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowFiltersDrawer(false)} />
          <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl max-h-[85vh] overflow-y-auto animate-slide-up">
            <div className="sticky top-0 bg-white flex items-center justify-between p-4 border-b border-neutral-100">
              <h2 className="text-lg font-bold text-neutral-900">Фильтры</h2>
              <button onClick={() => setShowFiltersDrawer(false)} className="btn-ghost btn-icon">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4">
              <FilterContent />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function VehicleCard({
  vehicle,
  isFavorite,
  onToggleFavorite,
}: {
  vehicle: Vehicle;
  isFavorite: boolean;
  onToggleFavorite: () => void;
}) {
  return (
    <Link to={`/cars/${vehicle.slug}`} className="card-hover group block">
      {/* Image */}
      <div className="relative overflow-hidden bg-neutral-200 aspect-[16/10]">
        <img
          src={vehicle.cover_photo}
          alt={`${vehicle.year} ${vehicle.brand.name} ${vehicle.model.name}`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onToggleFavorite();
          }}
          className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 hover:bg-white flex items-center justify-center transition-colors shadow-sm"
        >
          <Heart
            className={`w-4.5 h-4.5 transition-colors ${
              isFavorite ? 'text-red-500 fill-red-500' : 'text-neutral-400 hover:text-red-400'
            }`}
          />
        </button>
        {vehicle.condition === 'new' && (
          <span className="absolute top-3 left-3 badge-success text-white bg-accent-500">
            Новый
          </span>
        )}
        <span className="absolute bottom-3 left-3 badge bg-white/90 text-neutral-700 backdrop-blur-sm">
          {bodyTypeLabels[vehicle.body_type] || vehicle.body_type}
        </span>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-bold text-neutral-900 group-hover:text-primary-600 transition-colors mb-1">
          {vehicle.year} {vehicle.brand.name} {vehicle.model.name}
        </h3>

        <p className="text-xl font-bold text-primary-600 mb-3">
          {formatPrice(vehicle.price)}
        </p>

        {vehicle.credit_price_from && (
          <p className="text-xs text-neutral-500 mb-3">
            Кредит от {formatPrice(vehicle.credit_price_from)}/мес
          </p>
        )}

        <div className="flex flex-wrap gap-1.5 mb-3">
          <span className="badge-neutral">
            <Fuel className="w-3 h-3" />
            {engineTypeLabels[vehicle.engine_type] || vehicle.engine_type}
          </span>
          <span className="badge-neutral">
            <Settings2 className="w-3 h-3" />
            {transmissionLabels[vehicle.transmission] || vehicle.transmission}
          </span>
          <span className="badge-neutral">
            <Gauge className="w-3 h-3" />
            {formatMileage(vehicle.mileage)} км
          </span>
          <span className="badge-neutral">
            {driveLabels[vehicle.drive_type] || vehicle.drive_type}
          </span>
        </div>

        <p className="text-sm text-neutral-500">{vehicle.dealer.name}</p>
      </div>
    </Link>
  );
}
