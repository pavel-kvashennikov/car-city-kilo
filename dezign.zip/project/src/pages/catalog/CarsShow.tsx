import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  Heart, Phone, MapPin, ChevronRight, Share2, Clock, Fuel, Gauge,
  Settings2, Car as CarIcon, Palette, Shield, ChevronLeft,
  ChevronRight as ChevronRightIcon, Calendar, CreditCard,
  ArrowLeftRight, Eye, ShieldCheck, Award, Zap,
} from 'lucide-react';
import { vehicles } from '../../data';

const transmissionLabels: Record<string, string> = {
  manual: 'МКПП', automatic: 'АКПП', robot: 'Робот', cvt: 'Вариатор',
};

const engineTypeLabels: Record<string, string> = {
  petrol: 'Бензин', diesel: 'Дизель', hybrid: 'Гибрид', electric: 'Электро', gas: 'Газ',
};

const driveLabels: Record<string, string> = {
  fwd: 'Передний', rwd: 'Задний', awd: 'Полный', '4wd': '4WD',
};

const bodyTypeLabels: Record<string, string> = {
  sedan: 'Седан', suv: 'Внедорожник', hatchback: 'Хэтчбек', coupe: 'Купе',
  wagon: 'Универсал', minivan: 'Минивэн', pickup: 'Пикап',
};

const conditionLabels: Record<string, string> = {
  new: 'Новый', used: 'С пробегом', damaged: 'Повреждённый',
};

const legalStatusLabels: Record<string, string> = {
  clean: 'Чистый', credit: 'В кредите', arrest: 'Под арестом', duplicate: 'Дубликат ПТС',
};

const categoryLabels: Record<string, string> = {
  comfort: 'Комфорт', safety: 'Безопасность', multimedia: 'Мультимедиа',
};

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

export default function CarsShow() {
  const { slug } = useParams();
  const vehicle = vehicles.find((v) => v.slug === slug);
  const [selectedPhoto, setSelectedPhoto] = useState(0);
  const [showPhone, setShowPhone] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);

  if (!vehicle) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-neutral-50 to-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-neutral-100 to-neutral-200 flex items-center justify-center mx-auto mb-6">
            <CarIcon className="w-10 h-10 text-neutral-400" />
          </div>
          <h1 className="text-2xl font-bold text-neutral-900 mb-2">Автомобиль не найден</h1>
          <p className="text-neutral-500 mb-6">Возможно, он был снят с продажи</p>
          <Link to="/cars" className="btn-primary">
            <ChevronLeft className="w-4 h-4" />
            Вернуться к каталогу
          </Link>
        </div>
      </div>
    );
  }

  const photos = vehicle.photos.length > 0 ? vehicle.photos : [vehicle.cover_photo];
  const creditMonthly = vehicle.credit_price_from || Math.round(vehicle.price / 84);

  const similarVehicles = vehicles
    .filter((v) => v.id !== vehicle.id && (v.brand.id === vehicle.brand.id || v.body_type === vehicle.body_type))
    .slice(0, 3);

  const specs = [
    { label: 'Год', value: String(vehicle.year), icon: Clock },
    { label: 'Пробег', value: new Intl.NumberFormat('ru-RU').format(vehicle.mileage) + ' км', icon: Gauge },
    { label: 'Двигатель', value: `${engineTypeLabels[vehicle.engine_type]}, ${vehicle.engine_volume}L`, icon: Fuel },
    { label: 'Мощность', value: `${vehicle.engine_power} л.с.`, icon: Zap },
    { label: 'КПП', value: transmissionLabels[vehicle.transmission], icon: Settings2 },
    { label: 'Привод', value: driveLabels[vehicle.drive_type], icon: CarIcon },
    { label: 'Кузов', value: bodyTypeLabels[vehicle.body_type], icon: CarIcon },
    { label: 'Цвет', value: vehicle.color, icon: Palette },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-neutral-50 via-white to-neutral-50">
      {/* Hero Section with Title */}
      <div className="bg-gradient-to-br from-neutral-900 via-neutral-800 to-neutral-900 text-white">
        <div className="container-app py-4">
          <nav className="flex items-center gap-2 text-sm mb-6">
            <Link to="/" className="text-neutral-400 hover:text-white transition-colors">Главная</Link>
            <ChevronRight className="w-3.5 h-3.5 text-neutral-600" />
            <Link to="/cars" className="text-neutral-400 hover:text-white transition-colors">Автомобили</Link>
            <ChevronRight className="w-3.5 h-3.5 text-neutral-600" />
            <span className="text-white">{vehicle.brand.name} {vehicle.model.name}</span>
          </nav>

          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  vehicle.condition === 'new'
                    ? 'bg-gradient-to-r from-accent-400 to-accent-500 text-white'
                    : 'bg-white/10 text-neutral-300'
                }`}>
                  {conditionLabels[vehicle.condition]}
                </span>
                <span className="badge bg-white/10 backdrop-blur-sm border border-white/10 text-neutral-300">
                  {bodyTypeLabels[vehicle.body_type]}
                </span>
              </div>
              <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">
                {vehicle.year} {vehicle.brand.name} {vehicle.model.name}
                {vehicle.generation && ` ${vehicle.generation.name}`}
              </h1>
            </div>
            <div className="flex gap-2">
              <button onClick={() => setIsFavorite(!isFavorite)} className="btn-ghost btn-icon bg-white/10 hover:bg-white/20">
                <Heart className={`w-5 h-5 ${isFavorite ? 'text-red-400 fill-red-400' : 'text-white'}`} />
              </button>
              <button className="btn-ghost btn-icon bg-white/10 hover:bg-white/20">
                <Share2 className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Gallery Section */}
      <div className="container-app -mt-2 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-8">
          {/* Main Photo */}
          <div className="lg:col-span-3">
            <div className="relative rounded-2xl overflow-hidden aspect-[16/10] bg-neutral-900 shadow-2xl shadow-black/20">
              <img
                src={photos[selectedPhoto]}
                alt={`${vehicle.year} ${vehicle.brand.name} ${vehicle.model.name}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />

              {photos.length > 1 && (
                <>
                  <button
                    onClick={() => setSelectedPhoto(selectedPhoto === 0 ? photos.length - 1 : selectedPhoto - 1)}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/90 hover:bg-white flex items-center justify-center transition-all hover:scale-110 shadow-xl"
                  >
                    <ChevronLeft className="w-6 h-6 text-neutral-900" />
                  </button>
                  <button
                    onClick={() => setSelectedPhoto(selectedPhoto === photos.length - 1 ? 0 : selectedPhoto + 1)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/90 hover:bg-white flex items-center justify-center transition-all hover:scale-110 shadow-xl"
                  >
                    <ChevronRightIcon className="w-6 h-6 text-neutral-900" />
                  </button>
                </>
              )}

              {/* Photo counter & views */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <span className="bg-black/50 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium">
                  {selectedPhoto + 1} / {photos.length}
                </span>
                <span className="bg-black/50 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm flex items-center gap-2">
                  <Eye className="w-4 h-4" /> {vehicle.views_count} просмотров
                </span>
              </div>
            </div>

            {/* Thumbnails */}
            {photos.length > 1 && (
              <div className="flex gap-2 mt-3 overflow-x-auto scrollbar-hide py-1">
                {photos.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedPhoto(idx)}
                    className={`shrink-0 w-24 h-16 rounded-xl overflow-hidden border-2 transition-all ${
                      selectedPhoto === idx
                        ? 'border-primary-500 ring-4 ring-primary-500/20'
                        : 'border-transparent hover:border-neutral-300 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Price Card Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            <div className="card-glass p-6 text-center">
              <p className="text-sm text-neutral-500 mb-1">Цена</p>
              <p className="text-3xl font-bold bg-gradient-to-r from-primary-600 to-accent-500 bg-clip-text text-transparent mb-4">
                {formatPrice(vehicle.price)}
              </p>
              <div className="bg-gradient-to-r from-primary-50 to-accent-50 rounded-xl p-4 mb-4">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <CreditCard className="w-4 h-4 text-primary-500" />
                  <span className="text-xs text-neutral-500">Кредит от</span>
                </div>
                <p className="text-xl font-bold text-primary-600">
                  {formatPrice(creditMonthly)}/мес
                </p>
              </div>

              {/* Trust badges */}
              <div className="space-y-2 text-left">
                <div className="flex items-center gap-2 text-sm text-neutral-600">
                  <ShieldCheck className="w-4 h-4 text-accent-500" />
                  {legalStatusLabels[vehicle.legal_status]}
                </div>
                {vehicle.vin && (
                  <div className="flex items-center gap-2 text-sm text-neutral-600">
                    <Award className="w-4 h-4 text-primary-500" />
                    VIN проверен
                  </div>
                )}
              </div>
            </div>

            {/* Dealer Card */}
            <div className="card p-5">
              <p className="text-xs uppercase font-semibold text-neutral-400 tracking-wider mb-3">Продавец</p>
              <Link to={`/companies/${vehicle.dealer.slug}`} className="flex items-center gap-3 mb-4 group">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-100 to-accent-100 flex items-center justify-center shadow-inner">
                  <span className="text-lg font-bold bg-gradient-to-br from-primary-600 to-accent-500 bg-clip-text text-transparent">
                    {vehicle.dealer.name.charAt(0)}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-neutral-900 group-hover:text-primary-600 transition-colors">
                    {vehicle.dealer.name}
                  </p>
                  <p className="text-xs text-neutral-500">Официальный дилер</p>
                </div>
              </Link>
              <button onClick={() => setShowPhone(!showPhone)} className="btn-primary w-full">
                <Phone className="w-4 h-4" />
                {showPhone ? '+7 (495) 123-45-67' : 'Показать телефон'}
              </button>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              {vehicle.allows_test_drive && (
                <button className="btn-primary w-full btn-lg shadow-xl shadow-primary-500/20">
                  <Calendar className="w-5 h-5" />
                  Тест-драйв
                </button>
              )}
              {vehicle.allows_credit && (
                <button className="btn-secondary w-full">
                  <CreditCard className="w-4 h-4" />
                  Рассчитать кредит
                </button>
              )}
              {vehicle.allows_trade_in && (
                <button className="btn-secondary w-full">
                  <ArrowLeftRight className="w-4 h-4" />
                  Trade-in
                </button>
              )}
              <button onClick={() => setIsFavorite(!isFavorite)} className="btn-secondary w-full">
                <Heart className={`w-4 h-4 ${isFavorite ? 'text-red-500 fill-red-500' : ''}`} />
                {isFavorite ? 'В избранном' : 'В избранное'}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Specs & Details */}
      <div className="container-app pb-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Specs Grid */}
            <div className="card p-6">
              <h2 className="section-title mb-5">Характеристики</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {specs.map((spec) => (
                  <div key={spec.label} className="bg-gradient-to-br from-neutral-50 to-neutral-100/50 rounded-xl p-4 group hover:shadow-md transition-all">
                    <div className="flex items-center gap-2 text-neutral-400 text-xs font-medium mb-2">
                      <spec.icon className="w-4 h-4" />
                      {spec.label}
                    </div>
                    <div className="text-sm font-bold text-neutral-900">{spec.value}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Equipment */}
            {vehicle.equipment && Object.keys(vehicle.equipment).length > 0 && (
              <div className="card p-6">
                <h2 className="section-title mb-5">Комплектация</h2>
                <div className="space-y-5">
                  {Object.entries(vehicle.equipment).map(([category, items]) => (
                    <div key={category}>
                      <h3 className="text-sm font-semibold text-neutral-900 mb-3 flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary-500" />
                        {categoryLabels[category] || category}
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {(items as string[]).map((item) => (
                          <span key={item} className="badge-primary">
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Description */}
            <div className="card p-6">
              <h2 className="section-title mb-4">Описание</h2>
              <p className="text-neutral-600 leading-relaxed whitespace-pre-line">
                {vehicle.description}
              </p>
            </div>

            {/* Map Preview */}
            <div className="card p-6">
              <h2 className="section-title mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary-500" />
                Расположение на карте
              </h2>
              <div className="bg-gradient-to-br from-neutral-100 to-neutral-150 rounded-xl h-48 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-mesh opacity-30" />
                <div className="relative text-center">
                  <div className="w-14 h-14 rounded-full bg-white shadow-xl flex items-center justify-center mx-auto mb-3">
                    <MapPin className="w-7 h-7 text-primary-500" />
                  </div>
                  <p className="font-semibold text-neutral-900">{vehicle.dealer.name}</p>
                  <Link to="/map" className="text-sm text-primary-600 hover:text-primary-700 mt-1 inline-block">
                    Открыть карту →
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Similar Vehicles */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 space-y-4">
              <h3 className="font-bold text-neutral-900">Похожие автомобили</h3>
              {similarVehicles.map((sv) => (
                <Link key={sv.id} to={`/cars/${sv.slug}`} className="card-hover group flex gap-3 p-3">
                  <div className="w-24 h-16 rounded-lg overflow-hidden bg-neutral-200 shrink-0">
                    <img src={sv.cover_photo} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-neutral-900 group-hover:text-primary-600 transition-colors truncate">
                      {sv.year} {sv.brand.name} {sv.model.name}
                    </p>
                    <p className="text-base font-bold text-primary-600">{formatPrice(sv.price)}</p>
                    <p className="text-xs text-neutral-400">{sv.dealer.name}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
