import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ShoppingCart,
  Package,
  MapPin,
  Truck,
  Wrench,
  ChevronRight,
  Copy,
  Minus,
  Plus,
  ArrowLeft,
} from 'lucide-react';
import { products } from '../../data';
import type { Product } from '../../types';

export default function PartsShow() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);
  const [copiedOem, setCopiedOem] = useState(false);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  const product = useMemo(
    () => products.find((p) => p.slug === slug),
    [slug]
  );

  if (!product) {
    return (
      <div className="min-h-screen bg-neutral-50 flex items-center justify-center">
        <div className="text-center">
          <Package className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-neutral-900 mb-2">
            Товар не найден
          </h1>
          <button
            onClick={() => navigate('/parts')}
            className="btn btn-primary mt-4"
          >
            Вернуться в каталог
          </button>
        </div>
      </div>
    );
  }

  const handleCopyOem = () => {
    if (product.oem_number) {
      navigator.clipboard.writeText(product.oem_number);
      setCopiedOem(true);
      setTimeout(() => setCopiedOem(false), 2000);
    }
  };

  const priceFormatter = new Intl.NumberFormat('ru-RU');
  const displayImages = product.photos.length > 0 ? product.photos : [product.cover_photo];

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Breadcrumb Navigation */}
      <div className="bg-white border-b border-neutral-200">
        <div className="container-app py-4">
          <div className="flex items-center gap-2 text-sm">
            <button
              onClick={() => navigate('/parts')}
              className="text-primary-600 hover:text-primary-700 font-medium flex items-center gap-1"
            >
              <ArrowLeft className="w-4 h-4" />
              Запчасти
            </button>
            <ChevronRight className="w-4 h-4 text-neutral-400" />
            <button
              onClick={() => navigate(`/parts?category=${product.category.slug}`)}
              className="text-primary-600 hover:text-primary-700 font-medium"
            >
              {product.category.name}
            </button>
            <ChevronRight className="w-4 h-4 text-neutral-400" />
            <span className="text-neutral-600">{product.name}</span>
          </div>
        </div>
      </div>

      <div className="container-app py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Content */}
          <div className="lg:col-span-2">
            {/* Photo Section */}
            <div className="card p-6 mb-6">
              {/* Main Image */}
              <div className="mb-4 bg-neutral-100 rounded-lg overflow-hidden">
                <img
                  src={displayImages[selectedImageIndex]}
                  alt={product.name}
                  className="w-full h-96 object-cover"
                />
              </div>

              {/* Thumbnails */}
              {displayImages.length > 1 && (
                <div className="flex gap-3 overflow-x-auto pb-2">
                  {displayImages.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setSelectedImageIndex(index)}
                      className={`flex-shrink-0 w-20 h-20 rounded-lg border-2 transition-colors ${
                        selectedImageIndex === index
                          ? 'border-primary-500'
                          : 'border-neutral-200 hover:border-neutral-300'
                      }`}
                    >
                      <img
                        src={image}
                        alt={`Фото ${index + 1}`}
                        className="w-full h-full object-cover rounded-md"
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Product Name and Main Info */}
            <div className="mb-6">
              <span className="badge badge-neutral mb-3">{product.brand}</span>
              <h1 className="text-3xl font-bold text-neutral-900 mb-4">
                {product.name}
              </h1>

              {/* Article and OEM Numbers */}
              <div className="card p-6 mb-6">
                <h3 className="font-semibold text-neutral-900 mb-4">
                  Номера запчасти
                </h3>

                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-3 p-3 bg-primary-50 rounded-lg">
                    <div>
                      <p className="text-xs text-neutral-600 mb-1">Артикул</p>
                      <p className="font-mono font-semibold text-neutral-900">
                        {product.article_number}
                      </p>
                    </div>
                    <button className="btn btn-icon btn-ghost">
                      <Copy className="w-5 h-5" />
                    </button>
                  </div>

                  {product.oem_number && (
                    <div className="flex items-center justify-between gap-3 p-3 bg-primary-50 rounded-lg">
                      <div>
                        <p className="text-xs text-neutral-600 mb-1">
                          OEM-номер
                        </p>
                        <p className="font-mono font-semibold text-neutral-900">
                          {product.oem_number}
                        </p>
                      </div>
                      <button
                        onClick={handleCopyOem}
                        className="btn btn-icon btn-ghost relative"
                      >
                        <Copy className="w-5 h-5" />
                        {copiedOem && (
                          <span className="absolute -top-8 left-1/2 -translate-x-1/2 text-xs bg-neutral-900 text-white px-2 py-1 rounded whitespace-nowrap">
                            Скопировано!
                          </span>
                        )}
                      </button>
                    </div>
                  )}

                  {product.cross_numbers.length > 0 && (
                    <div className="p-3 bg-neutral-50 rounded-lg">
                      <p className="text-xs text-neutral-600 mb-2">
                        Аналоги
                      </p>
                      <p className="font-mono text-sm text-neutral-700">
                        {product.cross_numbers.join(', ')}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Price Section */}
              <div className="card p-6 mb-6">
                <div className="mb-4">
                  <p className="text-xs text-neutral-600 mb-1">Розничная цена</p>
                  <p className="text-4xl font-bold text-primary-600">
                    {priceFormatter.format(product.price_retail)} ₽
                  </p>
                </div>

                {product.price_wholesale && (
                  <div className="pt-4 border-t border-neutral-200">
                    <p className="text-xs text-neutral-600 mb-1">
                      Оптовая цена (от {product.wholesale_min_qty} шт.)
                    </p>
                    <p className="text-2xl font-bold text-accent-600">
                      {priceFormatter.format(product.price_wholesale)} ₽
                    </p>
                  </div>
                )}
              </div>

              {/* Stock Status */}
              <div className="card p-6 mb-6">
                <h3 className="font-semibold text-neutral-900 mb-3">
                  Статус наличия
                </h3>
                <div className="flex items-center justify-between">
                  <div>
                    {product.in_stock ? (
                      <>
                        <span className="badge badge-success mb-2">В наличии</span>
                        <p className="text-sm text-neutral-600">
                          Количество:{' '}
                          <span className="font-semibold text-neutral-900">
                            {product.quantity} шт.
                          </span>
                        </p>
                      </>
                    ) : (
                      <>
                        <span className="badge badge-error mb-2">
                          Нет в наличии
                        </span>
                        <p className="text-sm text-neutral-600">
                          Товар временно отсутствует
                        </p>
                      </>
                    )}
                  </div>
                  {product.in_stock && product.quantity < 5 && (
                    <span className="badge badge-warning">
                      Осталось мало!
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Applicability Table */}
            {product.applicability.length > 0 && (
              <div className="card p-6 mb-6">
                <h3 className="font-semibold text-neutral-900 mb-4 text-lg">
                  Совместимость с автомобилями
                </h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-neutral-200">
                        <th className="text-left py-3 px-2 font-semibold text-neutral-900">
                          Марка
                        </th>
                        <th className="text-left py-3 px-2 font-semibold text-neutral-900">
                          Модель
                        </th>
                        <th className="text-left py-3 px-2 font-semibold text-neutral-900">
                          Годы
                        </th>
                        <th className="text-left py-3 px-2 font-semibold text-neutral-900">
                          Коды двигателей
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {product.applicability.map((app, index) => (
                        <tr
                          key={index}
                          className="border-b border-neutral-100 hover:bg-neutral-50"
                        >
                          <td className="py-3 px-2 text-neutral-700">
                            {app.brand}
                          </td>
                          <td className="py-3 px-2 text-neutral-700">
                            {app.model}
                          </td>
                          <td className="py-3 px-2 text-neutral-700">
                            {app.year_from}
                            {app.year_to ? ` - ${app.year_to}` : ' - н.в.'}
                          </td>
                          <td className="py-3 px-2 text-neutral-700">
                            {app.engine_codes || '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Attributes Table */}
            {Object.keys(product.attributes).length > 0 && (
              <div className="card p-6 mb-6">
                <h3 className="font-semibold text-neutral-900 mb-4 text-lg">
                  Характеристики
                </h3>
                <div className="space-y-3">
                  {Object.entries(product.attributes).map(([key, value]) => (
                    <div
                      key={key}
                      className="flex justify-between items-start py-3 border-b border-neutral-100 last:border-b-0"
                    >
                      <span className="text-neutral-600 font-medium">{key}</span>
                      <span className="text-neutral-900 font-semibold">
                        {value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Description */}
            {product.description && (
              <div className="card p-6">
                <h3 className="font-semibold text-neutral-900 mb-4 text-lg">
                  Описание
                </h3>
                <p className="text-neutral-700 leading-relaxed">
                  {product.description}
                </p>
              </div>
            )}
          </div>

          {/* Right Column - Sidebar */}
          <div className="lg:col-span-1">
            {/* Sticky Sidebar */}
            <div className="space-y-4 sticky top-6">
              {/* Add to Cart Button */}
              <div className="card p-6">
                <h3 className="font-semibold text-neutral-900 mb-4">
                  Добавить в корзину
                </h3>

                {/* Quantity Selector */}
                <div className="mb-4">
                  <label className="text-sm text-neutral-600 mb-2 block">
                    Количество
                  </label>
                  <div className="flex items-center gap-2 bg-neutral-100 rounded-lg p-1 w-fit">
                    <button
                      onClick={() =>
                        setQuantity(Math.max(1, quantity - 1))
                      }
                      className="btn btn-icon btn-ghost"
                      disabled={quantity <= 1}
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <input
                      type="number"
                      min="1"
                      max={product.quantity}
                      value={quantity}
                      onChange={(e) =>
                        setQuantity(
                          Math.min(
                            product.quantity,
                            Math.max(1, parseInt(e.target.value) || 1)
                          )
                        )
                      }
                      className="w-12 text-center font-semibold bg-transparent border-0 focus:ring-0 focus:outline-none"
                    />
                    <button
                      onClick={() =>
                        setQuantity(
                          Math.min(product.quantity, quantity + 1)
                        )
                      }
                      className="btn btn-icon btn-ghost"
                      disabled={quantity >= product.quantity}
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Price for Selected Quantity */}
                <div className="mb-6 p-3 bg-primary-50 rounded-lg">
                  <p className="text-xs text-neutral-600 mb-1">
                    Итого за {quantity} {
                      quantity === 1
                        ? 'шт.'
                        : quantity >= 2 && quantity <= 4
                        ? 'шт.'
                        : 'шт.'
                    }
                  </p>
                  <p className="text-2xl font-bold text-primary-600">
                    {priceFormatter.format(
                      product.price_retail * quantity
                    )}{' '}
                    ₽
                  </p>
                </div>

                {/* Main Button */}
                <button
                  className="btn btn-primary w-full btn-lg justify-center mb-3"
                  disabled={!product.in_stock}
                >
                  <ShoppingCart className="w-5 h-5" />
                  В корзину
                </button>

                {!product.in_stock && (
                  <p className="text-center text-sm text-error-600 font-medium">
                    Товар отсутствует
                  </p>
                )}
              </div>

              {/* Store Info Card */}
              <div className="card p-6">
                <h3 className="font-semibold text-neutral-900 mb-4">
                  Информация
                </h3>

                <div className="space-y-4">
                  {/* Store */}
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Магазин</p>
                    <p className="font-semibold text-neutral-900">
                      {product.store.name}
                    </p>
                  </div>

                  {/* Location */}
                  {product.store.location && (
                    <div>
                      <p className="text-xs text-neutral-600 mb-1">
                        Местоположение
                      </p>
                      <button className="flex items-center gap-2 text-primary-600 hover:text-primary-700 font-medium">
                        <MapPin className="w-4 h-4" />
                        Показать на карте
                      </button>
                    </div>
                  )}

                  {/* Condition Badge */}
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Состояние</p>
                    <span className="badge badge-neutral">
                      {product.condition === 'new'
                        ? 'Новое'
                        : product.condition === 'used'
                        ? 'Б/У'
                        : 'Восстановленное'}
                    </span>
                  </div>

                  {/* Part Type */}
                  <div>
                    <p className="text-xs text-neutral-600 mb-1">Тип</p>
                    <span className="badge badge-accent">
                      {product.part_type === 'original'
                        ? 'Оригинал'
                        : product.part_type === 'oem'
                        ? 'OEM'
                        : 'Аналог'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Delivery Info */}
              <div className="card p-6">
                <h3 className="font-semibold text-neutral-900 mb-4 flex items-center gap-2">
                  <Truck className="w-5 h-5" />
                  Доставка
                </h3>
                <p className="text-sm text-neutral-600 mb-3">
                  Свяжитесь с продавцом для уточнения условий доставки и
                  сроков.
                </p>
                <button className="btn btn-secondary w-full justify-center">
                  Связаться с продавцом
                </button>
              </div>

              {/* Installation Service Link */}
              <button className="card p-6 w-full text-left hover:shadow-card-hover transition-shadow">
                <div className="flex items-start gap-3">
                  <Wrench className="w-5 h-5 text-accent-600 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-neutral-900 mb-1">
                      Подобрать установку
                    </h4>
                    <p className="text-xs text-neutral-600">
                      Найти мастера для установки этой запчасти
                    </p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-neutral-400 flex-shrink-0 ml-auto" />
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
