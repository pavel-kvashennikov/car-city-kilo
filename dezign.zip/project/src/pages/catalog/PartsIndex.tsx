import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Package,
  Filter,
  ShoppingCart,
  SlidersHorizontal,
  X,
  ChevronRight,
} from 'lucide-react';
import { products, partCategories } from '../../data';
import type { Product, PartCategory } from '../../types';

export default function PartsIndex() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    brands: [] as string[],
    conditions: [] as string[],
    partTypes: [] as string[],
    priceRange: [0, 50000],
    inStockOnly: false,
  });
  const [sortBy, setSortBy] = useState('relevance');

  const topCategories = useMemo(
    () => partCategories.filter((cat) => !cat.parent_id),
    []
  );

  const filteredProducts = useMemo(() => {
    let filtered = products.filter((product) => {
      const matchesSearch =
        searchQuery === '' ||
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.article_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.oem_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.cross_numbers.some((num) =>
          num.toLowerCase().includes(searchQuery.toLowerCase())
        );

      const matchesCategory = !selectedCategory || product.category.id === selectedCategory;

      const matchesBrand =
        filters.brands.length === 0 ||
        filters.brands.includes(product.brand);

      const matchesCondition =
        filters.conditions.length === 0 ||
        filters.conditions.includes(product.condition);

      const matchesPartType =
        filters.partTypes.length === 0 ||
        filters.partTypes.includes(product.part_type);

      const matchesPrice =
        product.price_retail >= filters.priceRange[0] &&
        product.price_retail <= filters.priceRange[1];

      const matchesStock =
        !filters.inStockOnly || product.in_stock;

      return (
        matchesSearch &&
        matchesCategory &&
        matchesBrand &&
        matchesCondition &&
        matchesPartType &&
        matchesPrice &&
        matchesStock
      );
    });

    if (sortBy === 'price-asc') {
      filtered.sort((a, b) => a.price_retail - b.price_retail);
    } else if (sortBy === 'price-desc') {
      filtered.sort((a, b) => b.price_retail - a.price_retail);
    } else if (sortBy === 'name') {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [searchQuery, selectedCategory, filters, sortBy]);

  const toggleBrand = (brand: string) => {
    setFilters((prev) => ({
      ...prev,
      brands: prev.brands.includes(brand)
        ? prev.brands.filter((b) => b !== brand)
        : [...prev.brands, brand],
    }));
  };

  const toggleCondition = (condition: string) => {
    setFilters((prev) => ({
      ...prev,
      conditions: prev.conditions.includes(condition)
        ? prev.conditions.filter((c) => c !== condition)
        : [...prev.conditions, condition],
    }));
  };

  const togglePartType = (type: string) => {
    setFilters((prev) => ({
      ...prev,
      partTypes: prev.partTypes.includes(type)
        ? prev.partTypes.filter((t) => t !== type)
        : [...prev.partTypes, type],
    }));
  };

  const uniqueBrands = Array.from(new Set(products.map((p) => p.brand))).sort();

  const priceFormatter = new Intl.NumberFormat('ru-RU');

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Hero Search Section */}
      <section className="bg-white border-b border-neutral-200 py-8 sm:py-12">
        <div className="container-app">
          <h1 className="page-title text-center mb-6">Запчасти</h1>

          {/* Search Input */}
          <div className="relative max-w-2xl mx-auto mb-3">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
            <input
              type="text"
              placeholder="Поиск по OEM-номеру, артикулу или названию..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="input pl-10"
            />
          </div>

          {/* Hint Text */}
          <p className="text-center text-sm text-neutral-500">
            Введите OEM-номер для быстрого поиска аналогов
          </p>
        </div>
      </section>

      {/* Category Navigation */}
      <section className="bg-white border-b border-neutral-200 py-4 overflow-x-auto">
        <div className="container-app">
          <div className="flex gap-2 pb-2 scrollbar-hide">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-full font-medium text-sm whitespace-nowrap transition-all ${
                selectedCategory === null
                  ? 'bg-primary-600 text-white'
                  : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
              }`}
            >
              Все
            </button>
            {topCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full font-medium text-sm whitespace-nowrap transition-all flex items-center gap-2 ${
                  selectedCategory === category.id
                    ? 'bg-primary-600 text-white'
                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                }`}
              >
                <Package className="w-4 h-4" />
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      <div className="container-app py-6 sm:py-8">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Filter Sidebar - Desktop */}
          <div className="hidden lg:block w-64 flex-shrink-0">
            <div className="card p-6 sticky top-6">
              <h3 className="font-semibold text-neutral-900 mb-4">Фильтры</h3>

              {/* Brand Filter */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-neutral-900 mb-3">
                  Бренд
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {uniqueBrands.map((brand) => (
                    <label key={brand} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.brands.includes(brand)}
                        onChange={() => toggleBrand(brand)}
                        className="w-4 h-4 rounded border-neutral-300"
                      />
                      <span className="text-sm text-neutral-700">{brand}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Condition Filter */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-neutral-900 mb-3">
                  Состояние
                </h4>
                <div className="space-y-2">
                  {['new', 'used', 'refurbished'].map((condition) => (
                    <label key={condition} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.conditions.includes(condition)}
                        onChange={() => toggleCondition(condition)}
                        className="w-4 h-4 rounded border-neutral-300"
                      />
                      <span className="text-sm text-neutral-700">
                        {condition === 'new'
                          ? 'Новое'
                          : condition === 'used'
                          ? 'Б/У'
                          : 'Восстановленное'}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Part Type Filter */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-neutral-900 mb-3">
                  Тип запчасти
                </h4>
                <div className="space-y-2">
                  {['original', 'oem', 'aftermarket'].map((type) => (
                    <label key={type} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={filters.partTypes.includes(type)}
                        onChange={() => togglePartType(type)}
                        className="w-4 h-4 rounded border-neutral-300"
                      />
                      <span className="text-sm text-neutral-700">
                        {type === 'original'
                          ? 'Оригинал'
                          : type === 'oem'
                          ? 'OEM'
                          : 'Аналог'}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="text-sm font-medium text-neutral-900 mb-3">
                  Цена, ₽
                </h4>
                <div className="space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="number"
                      min="0"
                      value={filters.priceRange[0]}
                      onChange={(e) =>
                        setFilters((prev) => ({
                          ...prev,
                          priceRange: [
                            parseInt(e.target.value) || 0,
                            prev.priceRange[1],
                          ],
                        }))
                      }
                      placeholder="От"
                      className="input text-sm flex-1"
                    />
                    <input
                      type="number"
                      min="0"
                      value={filters.priceRange[1]}
                      onChange={(e) =>
                        setFilters((prev) => ({
                          ...prev,
                          priceRange: [
                            prev.priceRange[0],
                            parseInt(e.target.value) || 50000,
                          ],
                        }))
                      }
                      placeholder="До"
                      className="input text-sm flex-1"
                    />
                  </div>
                </div>
              </div>

              {/* In Stock Toggle */}
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="in-stock"
                  checked={filters.inStockOnly}
                  onChange={(e) =>
                    setFilters((prev) => ({
                      ...prev,
                      inStockOnly: e.target.checked,
                    }))
                  }
                  className="w-4 h-4 rounded border-neutral-300"
                />
                <label htmlFor="in-stock" className="text-sm text-neutral-700 cursor-pointer">
                  Только в наличии
                </label>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Mobile Filter Button */}
            <div className="lg:hidden mb-4">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="btn btn-secondary w-full"
              >
                <SlidersHorizontal className="w-4 h-4" />
                Фильтры
              </button>
            </div>

            {/* Mobile Filter Drawer */}
            {showFilters && (
              <div className="lg:hidden card p-4 mb-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold text-neutral-900">Фильтры</h3>
                  <button
                    onClick={() => setShowFilters(false)}
                    className="btn-icon btn-ghost"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Mobile filters content (condensed version) */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium text-neutral-900 mb-2">
                      Состояние
                    </h4>
                    <div className="space-y-2">
                      {['new', 'used', 'refurbished'].map((condition) => (
                        <label key={condition} className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.conditions.includes(condition)}
                            onChange={() => toggleCondition(condition)}
                            className="w-4 h-4 rounded"
                          />
                          <span className="text-sm text-neutral-700">
                            {condition === 'new'
                              ? 'Новое'
                              : condition === 'used'
                              ? 'Б/У'
                              : 'Восстановленное'}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={filters.inStockOnly}
                        onChange={(e) =>
                          setFilters((prev) => ({
                            ...prev,
                            inStockOnly: e.target.checked,
                          }))
                        }
                        className="w-4 h-4 rounded"
                      />
                      <span className="text-sm text-neutral-700">
                        Только в наличии
                      </span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Sort and Count */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
              <p className="text-sm text-neutral-600">
                Найдено товаров: <span className="font-semibold">{filteredProducts.length}</span>
              </p>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="select sm:max-w-xs"
              >
                <option value="relevance">По релевантности</option>
                <option value="price-asc">По цене: возр.</option>
                <option value="price-desc">По цене: убыв.</option>
                <option value="name">По названию</option>
              </select>
            </div>

            {/* Products Grid */}
            {filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProducts.map((product) => (
                  <div
                    key={product.id}
                    className="card card-hover overflow-hidden flex flex-col cursor-pointer transition-transform hover:scale-105"
                    onClick={() => navigate(`/parts/${product.slug}`)}
                  >
                    {/* Product Image */}
                    <div className="relative h-48 bg-neutral-100 overflow-hidden">
                      <img
                        src={product.cover_photo}
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                      {!product.in_stock && (
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                          <span className="badge badge-error">Нет в наличии</span>
                        </div>
                      )}
                      {product.in_stock && product.quantity < 5 && (
                        <div className="absolute top-2 right-2">
                          <span className="badge badge-warning">Осталось {product.quantity}</span>
                        </div>
                      )}
                    </div>

                    {/* Product Info */}
                    <div className="p-4 flex-1 flex flex-col">
                      {/* Brand Tag */}
                      <span className="badge badge-neutral mb-2 w-fit">
                        {product.brand}
                      </span>

                      {/* Product Name */}
                      <h3 className="font-semibold text-neutral-900 mb-2 line-clamp-2 text-sm">
                        {product.name}
                      </h3>

                      {/* Article Numbers */}
                      <div className="text-xs text-neutral-500 mb-3">
                        <p>Артикул: {product.article_number}</p>
                        {product.oem_number && (
                          <p>OEM: {product.oem_number}</p>
                        )}
                      </div>

                      {/* Price Section */}
                      <div className="mb-4 mt-auto">
                        <p className="text-lg font-bold text-primary-600">
                          {priceFormatter.format(product.price_retail)} ₽
                        </p>
                        {product.price_wholesale && (
                          <p className="text-xs text-neutral-500">
                            Опт от {priceFormatter.format(product.price_wholesale)} ₽
                          </p>
                        )}
                      </div>

                      {/* Add to Cart Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          // Add to cart logic
                        }}
                        className="btn btn-primary w-full justify-center"
                        disabled={!product.in_stock}
                      >
                        <ShoppingCart className="w-4 h-4" />
                        В корзину
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="card p-12 text-center">
                <Package className="w-12 h-12 text-neutral-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-neutral-900 mb-2">
                  Товары не найдены
                </h3>
                <p className="text-neutral-600">
                  Попробуйте изменить критерии поиска или фильтры
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
