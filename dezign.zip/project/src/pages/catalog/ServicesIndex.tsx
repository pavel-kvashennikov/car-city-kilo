import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Wrench, Star, Clock, ChevronRight, MapPin } from 'lucide-react';
import { serviceProfiles, serviceCategories } from '../../data';

export default function ServicesIndex() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredServices = selectedCategory
    ? serviceProfiles.filter(service => service.category === selectedCategory)
    : serviceProfiles;

  const categories = [
    { id: 'maintenance', label: 'ТО' },
    { id: 'engine', label: 'Двигатель' },
    { id: 'suspension', label: 'Ходовая' },
    { id: 'bodywork', label: 'Кузовной ремонт' },
    { id: 'electrical', label: 'Электрика' },
    { id: 'diagnostics', label: 'Диагностика' },
    { id: 'tire_service', label: 'Шиномонтаж' },
    { id: 'ac_service', label: 'Кондиционер' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Автосервисы</h1>
          <p className="text-blue-100 text-lg">
            Найдите надежный автосервис для вашего автомобиля
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Category Filter */}
        <div className="mb-12">
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Категории услуг</h2>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-full font-medium transition-all ${
                selectedCategory === null
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:border-blue-600'
              }`}
            >
              Все услуги
            </button>
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full font-medium transition-all ${
                  selectedCategory === category.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-gray-700 border border-gray-300 hover:border-blue-600'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map(service => (
            <Link
              key={service.id}
              to={`/services/${service.slug}`}
              className="group bg-white rounded-lg shadow hover:shadow-xl transition-all overflow-hidden"
            >
              {/* Cover Photo */}
              <div className="relative h-48 bg-gray-200 overflow-hidden">
                {service.photo ? (
                  <img
                    src={service.photo}
                    alt={service.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-100 to-blue-200">
                    <Wrench className="w-12 h-12 text-blue-600" />
                  </div>
                )}
              </div>

              {/* Card Content */}
              <div className="p-5">
                {/* Name */}
                <h3 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {service.name}
                </h3>

                {/* Specialization Tags */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {service.specializations.slice(0, 2).map((spec, idx) => (
                    <span
                      key={idx}
                      className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full"
                    >
                      {spec}
                    </span>
                  ))}
                  {service.specializations.length > 2 && (
                    <span className="text-xs text-gray-500">
                      +{service.specializations.length - 2}
                    </span>
                  )}
                </div>

                {/* Rating and Reviews */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={
                          i < Math.floor(service.rating)
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-300'
                        }
                      />
                    ))}
                  </div>
                  <span className="text-sm font-medium text-gray-700">
                    {service.rating.toFixed(1)}
                  </span>
                  <span className="text-sm text-gray-500">
                    ({service.reviews_count})
                  </span>
                </div>

                {/* Working Hours */}
                <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
                  <Clock size={16} className="text-gray-400 flex-shrink-0" />
                  <span>Пн-Пт 09:00-20:00</span>
                </div>

                {/* Services Count Badge and Button */}
                <div className="flex items-center justify-between">
                  <span className="text-xs bg-gray-100 text-gray-700 px-3 py-1 rounded-full font-medium">
                    {service.services.length} услуг
                  </span>
                  <button className="text-blue-600 hover:text-blue-700 font-medium text-sm flex items-center gap-1 transition-colors">
                    Записаться
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Empty State */}
        {filteredServices.length === 0 && (
          <div className="text-center py-12">
            <Wrench className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              Услуги не найдены
            </h3>
            <p className="text-gray-500">
              Попробуйте выбрать другую категорию
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
