import { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Wrench,
  Star,
  Clock,
  Calendar,
  MapPin,
  User,
  Phone,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';
import { serviceProfiles } from '../../data';

interface ServiceSlot {
  time: string;
  available: boolean;
}

interface Master {
  id: string;
  name: string;
  specialization: string;
  rating: number;
}

export default function ServicesShow() {
  const { slug } = useParams<{ slug: string }>();
  const service = serviceProfiles.find(s => s.slug === slug);

  // Booking state
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [selectedMaster, setSelectedMaster] = useState<string | null>(null);
  const [carInfo, setCarInfo] = useState({ brand: '', model: '', year: '' });
  const [contact, setContact] = useState({ name: '', phone: '' });

  if (!service) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Wrench className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-gray-900">Сервис не найден</h1>
        </div>
      </div>
    );
  }

  // Mock masters data
  const masters: Master[] = [
    {
      id: '1',
      name: 'Иван Петров',
      specialization: 'Ремонт двигателя',
      rating: 4.8,
    },
    {
      id: '2',
      name: 'Сергей Иванов',
      specialization: 'Диагностика',
      rating: 4.9,
    },
    {
      id: '3',
      name: 'Алексей Смирнов',
      specialization: 'Кузовной ремонт',
      rating: 4.7,
    },
  ];

  // Mock working hours
  const workingHours = [
    { day: 'Пн', start: '09:00', end: '20:00' },
    { day: 'Вт', start: '09:00', end: '20:00' },
    { day: 'Ср', start: '09:00', end: '20:00' },
    { day: 'Чт', start: '09:00', end: '20:00' },
    { day: 'Пт', start: '09:00', end: '20:00' },
    { day: 'Сб', start: '10:00', end: '18:00' },
    { day: 'Вс', start: 'Выходной', end: '' },
  ];

  // Generate next 7 days
  const getNext7Days = () => {
    const days = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() + i);
      days.push(date);
    }
    return days;
  };

  // Mock time slots
  const getTimeSlots = (): ServiceSlot[] => {
    return [
      { time: '09:00', available: true },
      { time: '10:00', available: true },
      { time: '11:00', available: false },
      { time: '12:00', available: true },
      { time: '13:00', available: true },
      { time: '14:00', available: true },
      { time: '15:00', available: false },
      { time: '16:00', available: true },
      { time: '17:00', available: true },
      { time: '18:00', available: true },
      { time: '19:00', available: true },
    ];
  };

  const next7Days = getNext7Days();
  const timeSlots = getTimeSlots();

  const handleServiceToggle = (serviceId: string) => {
    setSelectedServices(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
    setSelectedTime(null);
  };

  const estimatedCost = selectedServices.reduce((total, serviceId) => {
    const svc = service.services.find(s => s.id === serviceId);
    if (svc?.price_type === 'fixed') {
      return total + (svc.price as number);
    }
    return total;
  }, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <a href="/services" className="hover:text-blue-600 transition-colors">
              Автосервисы
            </a>
            <ChevronRight size={16} />
            <span className="text-gray-900 font-medium">{service.name}</span>
          </div>
        </div>
      </div>

      {/* Service Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                {service.name}
              </h1>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className={
                        i < Math.floor(service.rating)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }
                    />
                  ))}
                  <span className="font-semibold text-gray-900">
                    {service.rating.toFixed(1)}
                  </span>
                </div>
                <span className="text-gray-600">
                  {service.reviews_count} отзывов
                </span>
              </div>
            </div>
          </div>

          {/* Specializations */}
          <div className="flex flex-wrap gap-2">
            {service.specializations.map((spec, idx) => (
              <span
                key={idx}
                className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium"
              >
                {spec}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <section className="bg-white rounded-lg shadow p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Описание</h2>
              <p className="text-gray-700 leading-relaxed">
                {service.description}
              </p>
            </section>

            {/* Working Hours */}
            <section className="bg-white rounded-lg shadow p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Clock size={24} className="text-blue-600" />
                Режим работы
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <tbody>
                    {workingHours.map((hours, idx) => (
                      <tr
                        key={idx}
                        className="border-b border-gray-200 last:border-b-0"
                      >
                        <td className="py-3 px-4 font-medium text-gray-900 w-20">
                          {hours.day}
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          {hours.start === 'Выходной'
                            ? 'Выходной'
                            : `${hours.start} - ${hours.end}`}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Masters */}
            <section className="bg-white rounded-lg shadow p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-2">
                <User size={24} className="text-blue-600" />
                Мастера
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {masters.map(master => (
                  <div
                    key={master.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                  >
                    <h3 className="font-bold text-gray-900 mb-2">
                      {master.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-3">
                      {master.specialization}
                    </p>
                    <div className="flex items-center gap-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={
                            i < Math.floor(master.rating)
                              ? 'fill-yellow-400 text-yellow-400'
                              : 'text-gray-300'
                          }
                        />
                      ))}
                      <span className="text-sm font-medium text-gray-700">
                        {master.rating.toFixed(1)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Price List */}
            <section className="bg-white rounded-lg shadow p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Прайс-лист
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b-2 border-gray-200">
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">
                        Услуга
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">
                        Цена
                      </th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">
                        Время
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {service.services.map(svc => (
                      <tr
                        key={svc.id}
                        className="border-b border-gray-200 last:border-b-0 hover:bg-gray-50"
                      >
                        <td className="py-3 px-4 text-gray-900">
                          {svc.name}
                        </td>
                        <td className="py-3 px-4 font-medium text-gray-900">
                          {svc.price_type === 'fixed'
                            ? `${svc.price} ₽`
                            : svc.price_type === 'range'
                            ? `${svc.price} ₽`
                            : 'По запросу'}
                        </td>
                        <td className="py-3 px-4 text-gray-600">
                          ~{svc.duration_minutes} мин
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </div>

          {/* Right Sidebar - Booking Card */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 bg-white rounded-lg shadow-lg p-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Записаться на сервис
              </h3>

              {/* Service Selector */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-900 mb-3">
                  Выберите услуги
                </label>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {service.services.map(svc => (
                    <label
                      key={svc.id}
                      className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedServices.includes(svc.id)}
                        onChange={() => handleServiceToggle(svc.id)}
                        className="w-4 h-4 text-blue-600 rounded"
                      />
                      <span className="text-sm text-gray-700 flex-1">
                        {svc.name}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Date Picker */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <Calendar size={16} />
                  Выберите дату
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {next7Days.map((date, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleDateSelect(date)}
                      className={`p-2 rounded text-center text-sm transition-all ${
                        selectedDate?.toDateString() === date.toDateString()
                          ? 'bg-blue-600 text-white font-semibold'
                          : 'border border-gray-300 text-gray-700 hover:border-blue-600'
                      }`}
                    >
                      <div className="text-xs font-medium">
                        {date.toLocaleDateString('ru-RU', { weekday: 'short' })}
                      </div>
                      <div className="text-sm">
                        {date.getDate()}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Time Slots */}
              {selectedDate && (
                <div className="mb-6">
                  <label className="block text-sm font-semibold text-gray-900 mb-3">
                    Выберите время
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {timeSlots.map((slot, idx) => (
                      <button
                        key={idx}
                        onClick={() =>
                          slot.available && setSelectedTime(slot.time)
                        }
                        disabled={!slot.available}
                        className={`py-2 px-2 rounded text-sm font-medium transition-all ${
                          !slot.available
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : selectedTime === slot.time
                            ? 'bg-blue-600 text-white'
                            : 'border border-gray-300 text-gray-700 hover:border-blue-600'
                        }`}
                      >
                        {slot.time}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Master Selector */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-900 mb-3">
                  Мастер (опционально)
                </label>
                <select
                  value={selectedMaster || ''}
                  onChange={e => setSelectedMaster(e.target.value || null)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none"
                >
                  <option value="">Выберите мастера</option>
                  {masters.map(master => (
                    <option key={master.id} value={master.id}>
                      {master.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Car Info */}
              <div className="mb-6 space-y-3">
                <label className="block text-sm font-semibold text-gray-900">
                  Информация об авто
                </label>
                <input
                  type="text"
                  placeholder="Марка"
                  value={carInfo.brand}
                  onChange={e =>
                    setCarInfo({ ...carInfo, brand: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none text-sm"
                />
                <input
                  type="text"
                  placeholder="Модель"
                  value={carInfo.model}
                  onChange={e =>
                    setCarInfo({ ...carInfo, model: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none text-sm"
                />
                <input
                  type="text"
                  placeholder="Год"
                  value={carInfo.year}
                  onChange={e =>
                    setCarInfo({ ...carInfo, year: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none text-sm"
                />
              </div>

              {/* Contact Info */}
              <div className="mb-6 space-y-3">
                <label className="block text-sm font-semibold text-gray-900">
                  Контактные данные
                </label>
                <input
                  type="text"
                  placeholder="Ваше имя"
                  value={contact.name}
                  onChange={e =>
                    setContact({ ...contact, name: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none text-sm"
                />
                <input
                  type="tel"
                  placeholder="Телефон"
                  value={contact.phone}
                  onChange={e =>
                    setContact({ ...contact, phone: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none text-sm"
                />
              </div>

              {/* Estimated Cost */}
              {estimatedCost > 0 && (
                <div className="mb-6 p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Примерная стоимость</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {estimatedCost} ₽
                  </p>
                </div>
              )}

              {/* Submit Button */}
              <button
                disabled={!selectedDate || !selectedTime || selectedServices.length === 0}
                className={`w-full py-3 rounded-lg font-bold text-white transition-all ${
                  !selectedDate || !selectedTime || selectedServices.length === 0
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700 active:scale-95'
                }`}
              >
                Записаться
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
