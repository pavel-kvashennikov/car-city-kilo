import { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ChevronRight,
  Star,
  Phone,
  Mail,
  MapPin,
  Clock,
  Home,
} from 'lucide-react';
import { companies, vehicles, products, serviceProfiles } from '../../data';

type TabType = 'overview' | 'vehicles' | 'parts' | 'service';

export default function CompaniesShow() {
  const { slug } = useParams<{ slug: string }>();
  const [activeTab, setActiveTab] = useState<TabType>('overview');

  const company = useMemo(
    () => companies.find((c) => c.slug === slug),
    [slug]
  );

  const companyVehicles = useMemo(
    () => company ? vehicles.filter((v) => v.dealer.id === company.id) : [],
    [company]
  );

  const companyProducts = useMemo(
    () => company ? products.filter((p) => p.store.id === company.id) : [],
    [company]
  );

  const companyService = useMemo(
    () => company ? serviceProfiles.find((s) => s.company.id === company.id) : null,
    [company]
  );

  if (!company) {
    return (
      <div className="container-app min-h-screen py-12 text-center">
        <p className="text-neutral-600">Компания не найдена</p>
      </div>
    );
  }

  const hasVehicles = company.profile_types.includes('dealer') && companyVehicles.length > 0;
  const hasProducts = company.profile_types.includes('parts') && companyProducts.length > 0;
  const hasService = company.profile_types.includes('service') && companyService;

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('ru-RU').format(price) + ' ₽';

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="container-app py-8">
        <nav className="mb-8 flex items-center gap-2 text-sm text-neutral-600">
          <Link to="/companies" className="hover:text-primary-600 transition-colors">
            Компании
          </Link>
          <ChevronRight className="h-4 w-4" />
          <span className="text-neutral-900 font-medium">{company.name}</span>
        </nav>

        <div className="mb-8 grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="card p-8">
              <div className="mb-6 flex items-start justify-between">
                <div>
                  <h1 className="page-title mb-3">{company.name}</h1>
                  <div className="flex flex-wrap gap-2">
                    {company.profile_types.map((type) => {
                      const labels: Record<string, string> = {
                        dealer: 'Дилер',
                        parts: 'Запчасти',
                        service: 'Сервис',
                      };
                      const colors: Record<string, string> = {
                        dealer: 'badge-primary',
                        parts: 'badge-accent',
                        service: 'badge-warning',
                      };
                      return (
                        <span key={type} className={`badge ${colors[type] || 'badge-neutral'}`}>
                          {labels[type] || type}
                        </span>
                      );
                    })}
                  </div>
                </div>
                <div className="text-right">
                  <div className="mb-1 flex items-center justify-end gap-1">
                    <Star className="h-5 w-5 fill-warning-400 text-warning-400" />
                    <span className="text-2xl font-bold text-neutral-900">
                      {company.rating}
                    </span>
                  </div>
                  <p className="text-sm text-neutral-600">
                    {company.reviews_count} отзывов
                  </p>
                </div>
              </div>

              <div className="border-t border-neutral-100 pt-6">
                <p className="mb-6 text-neutral-700 leading-relaxed">
                  {company.description}
                </p>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-primary-600 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-neutral-600">Телефон</p>
                      <a
                        href={`tel:${company.phone}`}
                        className="font-semibold text-neutral-900 hover:text-primary-600 transition-colors"
                      >
                        {company.phone}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-primary-600 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-neutral-600">Email</p>
                      <a
                        href={`mailto:${company.email}`}
                        className="font-semibold text-neutral-900 hover:text-primary-600 transition-colors"
                      >
                        {company.email}
                      </a>
                    </div>
                  </div>

                  {company.location && (
                    <div className="flex items-center gap-3">
                      <MapPin className="h-5 w-5 text-primary-600 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-neutral-600">Местоположение</p>
                        <p className="font-semibold text-neutral-900">
                          {company.location.zone.name} • {company.location.identifier}
                        </p>
                      </div>
                    </div>
                  )}

                  {hasService && companyService?.working_hours && (
                    <div className="flex items-center gap-3">
                      <Clock className="h-5 w-5 text-primary-600 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-neutral-600">Режим работы</p>
                        <p className="font-semibold text-neutral-900">
                          {companyService.working_hours.mon.open} - {companyService.working_hours.mon.close}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="border-t border-neutral-100 mt-6 pt-6">
                <div className="flex gap-2 overflow-x-auto pb-2">
                  <button
                    onClick={() => setActiveTab('overview')}
                    className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap transition-all duration-200 ${
                      activeTab === 'overview'
                        ? 'bg-primary-600 text-white'
                        : 'bg-white text-neutral-700 border border-neutral-200 hover:border-primary-300'
                    }`}
                  >
                    Обзор
                  </button>
                  {hasVehicles && (
                    <button
                      onClick={() => setActiveTab('vehicles')}
                      className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap transition-all duration-200 ${
                        activeTab === 'vehicles'
                          ? 'bg-primary-600 text-white'
                          : 'bg-white text-neutral-700 border border-neutral-200 hover:border-primary-300'
                      }`}
                    >
                      Автомобили ({companyVehicles.length})
                    </button>
                  )}
                  {hasProducts && (
                    <button
                      onClick={() => setActiveTab('parts')}
                      className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap transition-all duration-200 ${
                        activeTab === 'parts'
                          ? 'bg-primary-600 text-white'
                          : 'bg-white text-neutral-700 border border-neutral-200 hover:border-primary-300'
                      }`}
                    >
                      Запчасти ({companyProducts.length})
                    </button>
                  )}
                  {hasService && (
                    <button
                      onClick={() => setActiveTab('service')}
                      className={`px-4 py-2 font-medium rounded-lg whitespace-nowrap transition-all duration-200 ${
                        activeTab === 'service'
                          ? 'bg-primary-600 text-white'
                          : 'bg-white text-neutral-700 border border-neutral-200 hover:border-primary-300'
                      }`}
                    >
                      Сервис
                    </button>
                  )}
                </div>

                <div className="mt-6">
                  {activeTab === 'overview' && (
                    <div className="space-y-4">
                      <p className="text-neutral-700">Основная информация о компании загружена. Обратитесь к контактным данным для подробности.</p>
                    </div>
                  )}

                  {activeTab === 'vehicles' && hasVehicles && (
                    <div className="grid gap-4 sm:grid-cols-2">
                      {companyVehicles.map((vehicle) => (
                        <Link
                          key={vehicle.id}
                          to={`/cars/${vehicle.slug}`}
                          className="card-hover group overflow-hidden"
                        >
                          <div className="aspect-video overflow-hidden bg-neutral-200">
                            <img
                              src={vehicle.cover_photo}
                              alt={`${vehicle.brand.name} ${vehicle.model.name}`}
                              className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          </div>
                          <div className="p-4">
                            <h4 className="font-semibold text-neutral-900 group-hover:text-primary-600 transition-colors">
                              {vehicle.brand.name} {vehicle.model.name}
                            </h4>
                            <p className="text-sm text-neutral-600 mb-2">
                              {vehicle.year}, {vehicle.mileage.toLocaleString()} км
                            </p>
                            <p className="text-lg font-bold text-primary-600">
                              {formatPrice(vehicle.price)}
                            </p>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}

                  {activeTab === 'parts' && hasProducts && (
                    <div className="grid gap-4 sm:grid-cols-2">
                      {companyProducts.map((product) => (
                        <div key={product.id} className="card-hover p-4">
                          <div className="mb-3 flex gap-3">
                            <div className="h-16 w-16 flex-shrink-0 rounded-lg bg-neutral-200 overflow-hidden">
                              <img
                                src={product.cover_photo}
                                alt={product.name}
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <div className="flex-grow">
                              <h4 className="font-semibold text-neutral-900 text-sm line-clamp-2">
                                {product.name}
                              </h4>
                              <p className="text-xs text-neutral-600">
                                {product.article_number}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-primary-600">
                              {formatPrice(product.price_retail)}
                            </span>
                            {product.in_stock && (
                              <span className="badge badge-success text-xs">
                                В наличии
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {activeTab === 'service' && hasService && companyService && (
                    <div className="space-y-4">
                      {companyService.services.map((service) => (
                        <div key={service.id} className="card p-4">
                          <h4 className="font-semibold text-neutral-900 mb-2">
                            {service.name}
                          </h4>
                          <p className="text-sm text-neutral-600 mb-3">
                            {service.description}
                          </p>
                          <div className="flex items-center justify-between text-sm">
                            <span className="text-neutral-600">
                              ⏱ {service.duration_minutes} мин
                            </span>
                            <span className="font-semibold text-primary-600">
                              {service.price_type === 'fixed'
                                ? formatPrice(service.price_fixed || 0)
                                : service.price_type === 'range'
                                  ? `${formatPrice(service.price_min || 0)} - ${formatPrice(service.price_max || 0)}`
                                  : 'По договору'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="card sticky top-8 p-6">
              <h3 className="section-title mb-4">Быстрые контакты</h3>
              <div className="space-y-3">
                <a
                  href={`tel:${company.phone}`}
                  className="btn-primary w-full justify-center"
                >
                  <Phone className="h-4 w-4" />
                  Позвонить
                </a>
                <a
                  href={`mailto:${company.email}`}
                  className="btn-secondary w-full justify-center"
                >
                  <Mail className="h-4 w-4" />
                  Написать письмо
                </a>
              </div>

              {company.location && (
                <div className="mt-6 border-t border-neutral-100 pt-6">
                  <h4 className="font-semibold text-neutral-900 mb-2 flex items-center gap-2">
                    <Home className="h-4 w-4" />
                    Местоположение
                  </h4>
                  <div className="bg-neutral-100 rounded-lg p-3 text-center">
                    <p className="font-bold text-neutral-900">
                      {company.location.zone.name}
                    </p>
                    <p className="text-sm text-neutral-600">
                      {company.location.identifier}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
