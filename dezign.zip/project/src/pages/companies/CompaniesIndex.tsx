import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Star } from 'lucide-react';
import { companies } from '../../data';

type ProfileType = 'all' | 'dealer' | 'parts' | 'service';

export default function CompaniesIndex() {
  const [activeFilter, setActiveFilter] = useState<ProfileType>('all');

  const filteredCompanies = useMemo(() => {
    if (activeFilter === 'all') return companies;
    return companies.filter((c) => c.profile_types.includes(activeFilter));
  }, [activeFilter]);

  const filterLabels: Record<ProfileType, string> = {
    all: 'Все',
    dealer: 'Автодилеры',
    parts: 'Запчасти',
    service: 'Сервисы',
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((word) => word[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getProfileTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'dealer':
        return 'badge-primary';
      case 'parts':
        return 'badge-accent';
      case 'service':
        return 'badge-warning';
      default:
        return 'badge-neutral';
    }
  };

  const getProfileTypeLabel = (type: string) => {
    switch (type) {
      case 'dealer':
        return 'Дилер';
      case 'parts':
        return 'Запчасти';
      case 'service':
        return 'Сервис';
      default:
        return type;
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="container-app py-12">
        <div className="mb-12 text-center">
          <h1 className="page-title mb-3">Компании-резиденты</h1>
          <p className="text-neutral-600">Найдите надёжного партнёра на авторынке</p>
        </div>

        <div className="mb-8 flex flex-wrap gap-2 justify-center">
          {(Object.keys(filterLabels) as ProfileType[]).map((type) => (
            <button
              key={type}
              onClick={() => setActiveFilter(type)}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                activeFilter === type
                  ? 'bg-primary-600 text-white shadow-md'
                  : 'bg-white text-neutral-700 border border-neutral-200 hover:border-primary-300 hover:bg-primary-50'
              }`}
            >
              {filterLabels[type]}
            </button>
          ))}
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredCompanies.map((company) => (
            <Link
              key={company.id}
              to={`/companies/${company.slug}`}
              className="card-hover group flex flex-col p-6"
            >
              <div className="mb-4 flex items-center justify-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-primary-100 to-primary-200 text-2xl font-bold text-primary-700">
                  {getInitials(company.name)}
                </div>
              </div>

              <h3 className="mb-2 text-center text-lg font-semibold text-neutral-900 group-hover:text-primary-600 transition-colors">
                {company.name}
              </h3>

              <p className="mb-4 flex-grow text-sm text-neutral-600 text-center line-clamp-3">
                {company.description}
              </p>

              <div className="mb-4 flex flex-wrap gap-1 justify-center">
                {company.profile_types.map((type) => (
                  <span
                    key={type}
                    className={`badge ${getProfileTypeBadgeColor(type)}`}
                  >
                    {getProfileTypeLabel(type)}
                  </span>
                ))}
              </div>

              <div className="border-t border-neutral-100 pt-4">
                <div className="mb-3 flex items-center justify-center gap-1">
                  <div className="flex items-center gap-0.5">
                    <Star className="h-4 w-4 fill-warning-400 text-warning-400" />
                    <span className="font-semibold text-neutral-900">{company.rating}</span>
                  </div>
                  <span className="text-sm text-neutral-500">
                    ({company.reviews_count})
                  </span>
                </div>

                {company.location && (
                  <div className="flex items-center justify-center gap-1 text-sm text-neutral-600">
                    <MapPin className="h-4 w-4" />
                    <span>{company.location.identifier}</span>
                  </div>
                )}
              </div>

              <button className="mt-4 w-full rounded-lg bg-primary-50 py-2 text-center text-sm font-semibold text-primary-600 transition-all duration-200 hover:bg-primary-100">
                Подробнее
              </button>
            </Link>
          ))}
        </div>

        {filteredCompanies.length === 0 && (
          <div className="py-12 text-center">
            <p className="text-neutral-600">
              По вашему запросу ничего не найдено
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
