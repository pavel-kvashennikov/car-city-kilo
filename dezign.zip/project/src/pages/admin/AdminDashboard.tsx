import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  CheckCircle,
  XCircle,
  Building2,
  TrendingUp,
  ClipboardList,
  CreditCard,
  MapPin,
  Settings,
  BarChart3,
  DollarSign,
} from 'lucide-react';
import { companies } from '../../data';

type ApprovalStatus = 'pending' | 'approved' | 'rejected';

interface CompanyWithStatus {
  id: number;
  name: string;
  profile_types: string[];
  status: ApprovalStatus;
}

export default function AdminDashboard() {
  const [companiesWithStatus] = useState<CompanyWithStatus[]>(
    companies.map((c) => ({
      id: c.id,
      name: c.name,
      profile_types: c.profile_types,
      status: c.status === 'active' ? 'approved' : 'pending',
    }))
  );

  const stats = useMemo(() => {
    const total = companiesWithStatus.length;
    const approved = companiesWithStatus.filter((c) => c.status === 'approved').length;
    const pending = companiesWithStatus.filter((c) => c.status === 'pending').length;

    return {
      totalCompanies: total,
      activeCompanies: approved,
      pendingRequests: pending,
      monthlyRevenue: 2850000,
    };
  }, [companiesWithStatus]);

  const pendingCompanies = useMemo(
    () => companiesWithStatus.filter((c) => c.status === 'pending'),
    [companiesWithStatus]
  );

  const quickLinks = [
    { icon: Building2, label: 'Компании', href: '/admin/companies' },
    { icon: ClipboardList, label: 'Модерация', href: '/admin/moderation' },
    { icon: MapPin, label: 'Карта рынка', href: '/admin/map' },
    { icon: CreditCard, label: 'Биллинг', href: '/admin/billing' },
    { icon: Settings, label: 'Справочники', href: '/admin/references' },
  ];

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('ru-RU').format(price) + ' ₽';

  const getProfileTypeBadgeColor = (type: string) => {
    switch (type) {
      case 'dealer':
        return 'badge-primary';
      case 'parts':
        return 'badge-accent';
      case 'service':
        return 'badge-warning';
      default:
        return 'badge-neutral';
    }
  };

  const getProfileTypeLabel = (type: string) => {
    switch (type) {
      case 'dealer':
        return 'Дилер';
      case 'parts':
        return 'Запчасти';
      case 'service':
        return 'Сервис';
      default:
        return type;
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="container-app py-8">
        <div className="mb-8">
          <h1 className="page-title mb-2">Панель администратора</h1>
          <p className="text-neutral-600">Управление авторынком и компаниями</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          <div className="card p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-0">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-neutral-700 font-medium mb-1">
                  Компаний всего
                </p>
                <p className="text-3xl font-bold text-blue-600">
                  {stats.totalCompanies}
                </p>
              </div>
              <Building2 className="h-8 w-8 text-blue-600 opacity-50" />
            </div>
          </div>

          <div className="card p-6 bg-gradient-to-br from-green-50 to-green-100 border-0">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-neutral-700 font-medium mb-1">
                  Активных
                </p>
                <p className="text-3xl font-bold text-green-600">
                  {stats.activeCompanies}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600 opacity-50" />
            </div>
          </div>

          <div className="card p-6 bg-gradient-to-br from-orange-50 to-orange-100 border-0">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-neutral-700 font-medium mb-1">
                  На модерации
                </p>
                <p className="text-3xl font-bold text-orange-600">
                  {stats.pendingRequests}
                </p>
              </div>
              <ClipboardList className="h-8 w-8 text-orange-600 opacity-50" />
            </div>
          </div>

          <div className="card p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-0">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-sm text-neutral-700 font-medium mb-1">
                  Доход за месяц
                </p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatPrice(stats.monthlyRevenue)}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600 opacity-50" />
            </div>
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="card p-6 mb-8">
              <h2 className="section-title mb-6">Компании на модерации</h2>

              {pendingCompanies.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-3 opacity-50" />
                  <p className="text-neutral-600">
                    Все компании одобрены. Новых заявок нет.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingCompanies.map((company) => (
                    <div
                      key={company.id}
                      className="border border-neutral-150 rounded-lg p-4 hover:border-primary-300 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-neutral-900 mb-1">
                            {company.name}
                          </h3>
                          <div className="flex flex-wrap gap-1">
                            {company.profile_types.map((type) => (
                              <span
                                key={type}
                                className={`badge ${getProfileTypeBadgeColor(type)}`}
                              >
                                {getProfileTypeLabel(type)}
                              </span>
                            ))}
                          </div>
                        </div>
                        <span className="badge badge-warning">
                          На рассмотрении
                        </span>
                      </div>

                      <div className="flex gap-2 pt-3 border-t border-neutral-100">
                        <button className="btn btn-primary btn-sm flex-1">
                          <CheckCircle className="h-4 w-4" />
                          Одобрить
                        </button>
                        <button className="btn btn-danger btn-sm flex-1">
                          <XCircle className="h-4 w-4" />
                          Отклонить
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="card p-6">
              <h2 className="section-title mb-6">Все компании</h2>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-neutral-100">
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Компания
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Типы
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Статус
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Действия
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {companiesWithStatus.map((company) => (
                      <tr
                        key={company.id}
                        className="border-b border-neutral-100 hover:bg-neutral-50 transition-colors"
                      >
                        <td className="py-3 px-3">
                          <span className="font-semibold text-neutral-900">
                            {company.name}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex flex-wrap gap-1">
                            {company.profile_types.map((type) => (
                              <span
                                key={type}
                                className={`badge ${getProfileTypeBadgeColor(type)}`}
                              >
                                {getProfileTypeLabel(type)}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span
                            className={`badge ${
                              company.status === 'approved'
                                ? 'badge-success'
                                : 'badge-warning'
                            }`}
                          >
                            {company.status === 'approved'
                              ? 'Активна'
                              : 'На рассмотрении'}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <Link
                            to={`/admin/companies/${company.id}`}
                            className="text-primary-600 hover:text-primary-700 font-medium text-sm"
                          >
                            Просмотр →
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-8">
              <h2 className="section-title mb-6">Быстрые ссылки</h2>

              <div className="space-y-2">
                {quickLinks.map((link, idx) => {
                  const Icon = link.icon;
                  return (
                    <Link
                      key={idx}
                      to={link.href}
                      className="flex items-center gap-3 p-3 rounded-lg border border-neutral-150 hover:border-primary-300 hover:bg-primary-50 transition-all duration-200"
                    >
                      <Icon className="h-5 w-5 text-primary-600 flex-shrink-0" />
                      <span className="font-medium text-neutral-900">
                        {link.label}
                      </span>
                    </Link>
                  );
                })}
              </div>

              <div className="mt-6 border-t border-neutral-100 pt-6">
                <h3 className="font-semibold text-neutral-900 mb-3 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-primary-600" />
                  Быстрая статистика
                </h3>

                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-neutral-600">Загруженность</span>
                    <span className="font-semibold text-neutral-900">75%</span>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div className="bg-primary-600 h-2 rounded-full w-3/4" />
                  </div>

                  <div className="flex items-center justify-between pt-3">
                    <span className="text-neutral-600">Среднее время ответа</span>
                    <span className="font-semibold text-neutral-900">2ч 15м</span>
                  </div>

                  <div className="flex items-center justify-between pt-3">
                    <span className="text-neutral-600">Резервируемость</span>
                    <span className="font-semibold text-neutral-900">85%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
