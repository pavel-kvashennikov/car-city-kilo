import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Search, Car, Package, Wrench, Star, MapPin, TrendingUp,
  ChevronRight, ArrowRight, Users, Zap, Shield, Clock, Award
} from 'lucide-react';
import { vehicles, products, serviceProfiles } from '../../data';

export default function HomePage() {
  const [searchTab, setSearchTab] = useState<'cars' | 'parts' | 'services'>('cars');

  const priceFormatter = new Intl.NumberFormat('ru-RU');
  const formatPrice = (price: number) => `${priceFormatter.format(price)} ₽`;

  const topVehicles = vehicles.slice(0, 6);
  const topParts = products.slice(0, 6);
  const topServices = serviceProfiles.slice(0, 3);

  return (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative w-full overflow-hidden">
        {/* Background with mesh gradient */}
        <div className="absolute inset-0 bg-mesh" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary-600/90 via-primary-700/85 to-accent-600/80" />

        {/* Decorative elements */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent-400/10 rounded-full blur-3xl animate-pulse-slow" />

        <div className="container-app relative py-20 md:py-32 lg:py-40">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Hero Content */}
            <div className="animate-fade-in">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white/90 text-sm font-medium mb-6">
                <Zap className="w-4 h-4 text-accent-300" />
                Более 150 резидентов на платформе
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-[1.1] tracking-tight">
                Найдите идеальный автомобиль, запчасти или сервис
              </h1>

              <p className="text-lg md:text-xl text-white/80 mb-8 max-w-xl">
                Весь авторынок в одном месте. Новые и с пробегом автомобили от дилеров, запчасти с доставкой, проверенные автосервисы.
              </p>

              {/* Search Box */}
              <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl shadow-black/10 overflow-hidden">
                {/* Tabs */}
                <div className="flex bg-neutral-100/50">
                  {(['cars', 'parts', 'services'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setSearchTab(tab)}
                      className={`flex-1 px-6 py-4 text-sm font-semibold transition-all duration-300 relative ${
                        searchTab === tab
                          ? 'text-primary-700'
                          : 'text-neutral-500 hover:text-neutral-700'
                      }`}
                    >
                      {searchTab === tab && (
                        <span className="absolute inset-0 bg-white shadow-sm" />
                      )}
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {tab === 'cars' && <Car className="w-4 h-4" />}
                        {tab === 'parts' && <Package className="w-4 h-4" />}
                        {tab === 'services' && <Wrench className="w-4 h-4" />}
                        {tab === 'cars' && 'Автомобили'}
                        {tab === 'parts' && 'Запчасти'}
                        {tab === 'services' && 'Сервисы'}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Search Input */}
                <div className="p-5">
                  <div className="flex gap-3">
                    <div className="flex-1 relative">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-neutral-400 w-5 h-5" />
                      <input
                        type="text"
                        placeholder={
                          searchTab === 'cars'
                            ? 'Марка, модель или характеристика...'
                            : searchTab === 'parts'
                            ? 'Название, OEM-номер или артикул...'
                            : 'Тип услуги или название сервиса...'
                        }
                        className="input pl-12 border-0 bg-neutral-50 focus:bg-white focus:ring-primary-500/20"
                      />
                    </div>
                    <button className="btn-primary rounded-2xl px-7">
                      <Search className="w-5 h-5" />
                      <span className="hidden sm:inline">Найти</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="flex flex-wrap items-center gap-6 mt-8">
                {[
                  { icon: Shield, label: 'Проверенные дилеры' },
                  { icon: Clock, label: 'Онлайн-запись' },
                  { icon: Award, label: 'Гарантия качества' },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-white/80 text-sm">
                    <item.icon className="w-4 h-4" />
                    {item.label}
                  </div>
                ))}
              </div>
            </div>

            {/* Hero Image */}
            <div className="hidden lg:block relative animate-fade-in">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-tr from-primary-500/20 to-accent-500/20 rounded-3xl blur-2xl" />
                <img
                  src="https://images.pexels.com/photos/1545743/pexels-photo-1545743.jpeg?auto=compress&cs=tinysrgb&w=1200"
                  alt="Автомобиль на авторынке"
                  className="relative rounded-3xl shadow-2xl shadow-black/20 w-full h-[500px] object-cover"
                />

                {/* Floating Stats Card */}
                <div className="absolute -bottom-6 -left-6 bg-white/95 backdrop-blur-xl rounded-2xl p-5 shadow-xl shadow-black/5">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-neutral-900">5000+</p>
                      <p className="text-sm text-neutral-500">Автомобилей</p>
                    </div>
                  </div>
                </div>

                {/* Floating Stats Card 2 */}
                <div className="absolute -top-4 -right-4 bg-white/95 backdrop-blur-xl rounded-2xl p-4 shadow-xl shadow-black/5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-400 to-accent-500 flex items-center justify-center">
                      <Users className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-lg font-bold text-neutral-900">150+</p>
                      <p className="text-xs text-neutral-500">Резидентов</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave Divider */}
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 120" fill="none" className="w-full">
            <path d="M0,64 C480,150 960,0 1440,64 L1440,120 L0,120 Z" fill="white" fillOpacity="0.1" />
            <path d="M0,96 C480,0 960,150 1440,64 L1440,120 L0,120 Z" fill="white" />
          </svg>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 md:py-28 bg-gradient-to-b from-white to-neutral-50/50">
        <div className="container-app">
          <div className="text-center mb-16">
            <h2 className="page-title text-4xl md:text-5xl mb-4">
              Три способа найти то, что нужно
            </h2>
            <p className="text-lg text-neutral-500 max-w-2xl mx-auto">
              Автомобили от дилеров, запчасти с доставкой, проверенные автосервисы
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {[
              { icon: Car, title: 'Автомобили', desc: 'Новые и с пробегом от проверенных дилеров', href: '/cars', color: 'from-primary-500 to-primary-600' },
              { icon: Package, title: 'Запчасти', desc: 'Оригинал и аналоги, поиск по OEM-номеру', href: '/parts', color: 'from-accent-500 to-accent-600' },
              { icon: Wrench, title: 'Автосервисы', desc: 'ТО, диагностика, ремонт с онлайн-записью', href: '/services', color: 'from-amber-500 to-orange-500' },
            ].map((category, idx) => (
              <Link
                key={idx}
                to={category.href}
                className="group relative overflow-hidden"
              >
                <div className="card-hover p-8 lg:p-10 h-full">
                  {/* Background gradient on hover */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} />

                  <div className={`inline-flex p-4 rounded-2xl bg-gradient-to-br ${category.color} mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <category.icon className="w-8 h-8 text-white" />
                  </div>

                  <h3 className="text-xl lg:text-2xl font-bold text-neutral-900 mb-3 group-hover:text-primary-600 transition-colors">
                    {category.title}
                  </h3>
                  <p className="text-neutral-500 mb-6 leading-relaxed">{category.desc}</p>

                  <div className="flex items-center text-primary-600 font-semibold group-hover:gap-3 gap-2 transition-all">
                    <span>Перейти</span>
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Vehicles Section */}
      <section className="py-20 md:py-28 bg-neutral-50/50">
        <div className="container-app">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <h2 className="page-title text-3xl md:text-4xl mb-2">Популярные автомобили</h2>
              <p className="text-neutral-500">Лучшие предложения от наших дилеров</p>
            </div>
            <Link to="/cars" className="btn-secondary">
              Смотреть все
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {topVehicles.map((vehicle, idx) => (
              <Link
                key={vehicle.id}
                to={`/cars/${vehicle.slug}`}
                className="group flex flex-col"
              >
                <div className="card-hover overflow-hidden flex-1 flex flex-col">
                  {/* Image */}
                  <div className="relative overflow-hidden aspect-[16/10] bg-neutral-200">
                    <img
                      src={vehicle.cover_photo}
                      alt={`${vehicle.brand.name} ${vehicle.model.name}`}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                    {vehicle.condition === 'new' && (
                      <div className="absolute top-4 left-4">
                        <span className="badge-success">Новый</span>
                      </div>
                    )}

                    <div className="absolute bottom-4 left-4 right-4 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-300">
                      <button className="btn-primary btn-sm w-full">
                        Подробнее
                      </button>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <h3 className="font-bold text-lg text-neutral-900 group-hover:text-primary-600 transition-colors">
                        {vehicle.year} {vehicle.brand.name} {vehicle.model.name}
                      </h3>
                    </div>

                    <p className="text-2xl font-bold text-primary-600 mb-4">
                      {formatPrice(vehicle.price)}
                    </p>

                    {/* Specs */}
                    <div className="grid grid-cols-3 gap-3 mb-4 text-sm">
                      <div className="text-center p-2 rounded-lg bg-neutral-50">
                        <p className="text-neutral-400 text-xs">Пробег</p>
                        <p className="font-semibold text-neutral-900">{vehicle.mileage.toLocaleString('ru-RU')} км</p>
                      </div>
                      <div className="text-center p-2 rounded-lg bg-neutral-50">
                        <p className="text-neutral-400 text-xs">КПП</p>
                        <p className="font-semibold text-neutral-900">{vehicle.transmission === 'automatic' ? 'АКПП' : 'МКПП'}</p>
                      </div>
                      <div className="text-center p-2 rounded-lg bg-neutral-50">
                        <p className="text-neutral-400 text-xs">Объём</p>
                        <p className="font-semibold text-neutral-900">{vehicle.engine_volume} л</p>
                      </div>
                    </div>

                    <div className="mt-auto pt-4 border-t border-neutral-100 flex items-center justify-between">
                      <span className="text-sm text-neutral-500">{vehicle.dealer.name}</span>
                      <ChevronRight className="w-4 h-4 text-primary-500" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Parts Section */}
      <section className="py-20 md:py-28">
        <div className="container-app">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <h2 className="page-title text-3xl md:text-4xl mb-2">Популярные запчасти</h2>
              <p className="text-neutral-500">Оригинальные детали и качественные аналоги</p>
            </div>
            <Link to="/parts" className="btn-secondary">
              Смотреть все
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="overflow-x-auto -mx-4 sm:mx-0 scrollbar-hide">
            <div className="flex gap-5 px-4 sm:px-0 pb-2">
              {topParts.map((part) => (
                <Link
                  key={part.id}
                  to={`/parts/${part.slug}`}
                  className="group flex-shrink-0 w-72"
                >
                  <div className="card-hover overflow-hidden h-full">
                    <div className="relative overflow-hidden h-44 bg-neutral-100">
                      <img
                        src={part.cover_photo}
                        alt={part.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>

                    <div className="p-5">
                      <h3 className="font-semibold text-neutral-900 mb-2 line-clamp-2 group-hover:text-primary-600 transition-colors">
                        {part.name}
                      </h3>

                      <p className="text-xs text-neutral-400 mb-3 font-mono">
                        {part.article_number}
                      </p>

                      <div className="flex items-end justify-between">
                        <p className="text-xl font-bold text-primary-600">
                          {formatPrice(part.price_retail)}
                        </p>
                        {part.in_stock ? (
                          <span className="badge-success text-xs">В наличии</span>
                        ) : (
                          <span className="badge-warning text-xs">Под заказ</span>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 md:py-28 bg-gradient-to-b from-neutral-50/50 to-white">
        <div className="container-app">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
            <div>
              <h2 className="page-title text-3xl md:text-4xl mb-2">Рекомендуемые сервисы</h2>
              <p className="text-neutral-500">Проверенные автосервисы с онлайн-записью</p>
            </div>
            <Link to="/services" className="btn-secondary">
              Смотреть все
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {topServices.map((service) => (
              <Link key={service.id} to={`/services/${service.slug}`} className="group">
                <div className="card-hover overflow-hidden h-full">
                  <div className="relative overflow-hidden h-48 bg-neutral-200">
                    <img
                      src={service.cover_photo}
                      alt={service.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

                    {/* Rating Badge */}
                    <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-white/95 backdrop-blur-sm rounded-xl px-3 py-1.5 shadow-lg">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      <span className="font-bold text-neutral-900">{service.rating.toFixed(1)}</span>
                      <span className="text-xs text-neutral-400">({service.reviews_count})</span>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="font-bold text-lg text-neutral-900 mb-3 group-hover:text-primary-600 transition-colors">
                      {service.name}
                    </h3>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {service.specializations.slice(0, 3).map((spec, i) => (
                        <span key={i} className="badge-primary text-xs">{spec}</span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-sm text-neutral-500">
                        {service.services.length} услуг
                      </span>
                      <ChevronRight className="w-4 h-4 text-primary-500 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Market Map CTA */}
      <section className="py-20 md:py-28">
        <div className="container-app">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-600 via-primary-700 to-accent-600 p-10 md:p-16 lg:p-20">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-60 h-60 bg-black/10 rounded-full blur-2xl" />

            <div className="relative grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                  Интерактивная карта авторынка
                </h2>
                <p className="text-lg text-white/80 mb-8 leading-relaxed">
                  Навигируйте по павильонам и боксам. Найдите дилеров, магазины запчастей и сервисы на интерактивной карте.
                </p>

                <Link to="/map" className="btn-primary bg-white text-primary-700 hover:bg-neutral-100 shadow-xl">
                  <MapPin className="w-5 h-5" />
                  Открыть карту
                </Link>
              </div>

              {/* Map preview */}
              <div className="hidden lg:block">
                <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/20">
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    {[
                      { label: 'Дилеры', color: 'bg-primary-400', count: '45' },
                      { label: 'Запчасти', color: 'bg-accent-400', count: '32' },
                      { label: 'Сервисы', color: 'bg-amber-400', count: '18' },
                    ].map((item) => (
                      <div key={item.label} className="text-center">
                        <div className={`w-10 h-10 ${item.color} rounded-xl mx-auto mb-2 shadow-lg`} />
                        <p className="text-white font-bold">{item.count}</p>
                        <p className="text-white/60 text-xs">{item.label}</p>
                      </div>
                    ))}
                  </div>
                  <div className="h-32 bg-white/10 rounded-xl flex items-center justify-center">
                    <MapPin className="w-8 h-8 text-white/40" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-neutral-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary-500 rounded-full blur-3xl opacity-20" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent-500 rounded-full blur-3xl opacity-20" />
        </div>

        <div className="container-app relative">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6">
              Станьте резидентом авторынка
            </h2>
            <p className="text-lg text-neutral-400 mb-10 max-w-2xl mx-auto">
              Разместите свои автомобили, запчасти или услуги на ведущей платформе. Получайте клиентов, растите вместе с нами.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary btn-lg bg-white text-primary-700 hover:bg-neutral-100">
                <Users className="w-5 h-5" />
                Зарегистрироваться
              </button>
              <button className="btn-secondary btn-lg border-neutral-700 text-white hover:bg-neutral-800">
                Смотреть тарифы
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
              {[
                { icon: TrendingUp, title: 'Больше продаж', desc: 'Доступ к тысячам клиентов' },
                { icon: Zap, title: 'Простая аналитика', desc: 'Отслеживайте лиды в реальном времени' },
                { icon: Shield, title: 'Надежность', desc: 'Платформа с проверенными резидентами' },
              ].map((item) => (
                <div key={item.title} className="text-left p-6 rounded-2xl bg-white/5 border border-white/10">
                  <item.icon className="w-8 h-8 text-primary-400 mb-4" />
                  <h3 className="font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-sm text-neutral-400">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
