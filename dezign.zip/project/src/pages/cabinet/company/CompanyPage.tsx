import { useState } from 'react';
import { Building2, Phone, Mail, Globe, MapPin, Save } from 'lucide-react';
import { companies } from '../../../data';

export default function CompanyPage() {
  const company = companies[0];
  const [form, setForm] = useState({
    name: company?.name || '',
    legal_name: company?.legal_name || '',
    inn: company?.inn || '',
    phone: company?.phone || '',
    email: company?.email || '',
    website: company?.website || '',
    description: company?.description || '',
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Компания</h1>
        <button className="btn-primary">
          <Save className="w-4 h-4" />
          Сохранить
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h2 className="text-base font-bold text-neutral-900 mb-4">Основная информация</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Название</label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input pl-9" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Юридическое название</label>
              <input value={form.legal_name} onChange={(e) => setForm({ ...form, legal_name: e.target.value })} className="input" />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">ИНН</label>
              <input value={form.inn} onChange={(e) => setForm({ ...form, inn: e.target.value })} className="input" />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Описание</label>
              <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={4} className="input" />
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="text-base font-bold text-neutral-900 mb-4">Контакты</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Телефон</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input pl-9" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input pl-9" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Сайт</label>
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                <input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} className="input pl-9" />
              </div>
            </div>
          </div>

          <h2 className="text-base font-bold text-neutral-900 mt-6 mb-4">Расположение</h2>
          <div className="bg-neutral-50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-sm text-neutral-600">
              <MapPin className="w-4 h-4 text-primary-500" />
              {company?.location ? `${company.location.identifier} — ${company.location.zone.name}` : 'Не указано'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
