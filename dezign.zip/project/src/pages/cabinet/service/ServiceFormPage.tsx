import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save } from 'lucide-react';
import { serviceCategories } from '../../../data';

export default function ServiceFormPage() {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '',
    category_id: '',
    description: '',
    price_type: 'fixed',
    price_fixed: '',
    price_min: '',
    price_max: '',
    duration_minutes: 60,
    slot_size: 1,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await new Promise((r) => setTimeout(r, 1000));
    navigate('/cabinet/service');
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="btn-ghost btn-icon">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="page-title">Добавить услугу</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-5">
          <h2 className="section-title mb-4">Основная информация</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Название *</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Замена масла"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Категория *</label>
              <select
                value={form.category_id}
                onChange={(e) => setForm({ ...form, category_id: e.target.value })}
                required
                className="select"
              >
                <option value="">Выберите категорию</option>
                {serviceCategories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Описание</label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={3}
                placeholder="Опишите услугу подробнее..."
                className="input"
              />
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Стоимость</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-2">Тип ценообразования</label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {[
                  { value: 'fixed', label: 'Фиксированная' },
                  { value: 'hourly', label: 'По нормо-часам' },
                  { value: 'range', label: 'Диапазон' },
                  { value: 'by_agreement', label: 'По договорённости' },
                ].map((opt) => (
                  <label
                    key={opt.value}
                    className={`flex items-center justify-center gap-2 px-3 py-2 rounded-lg border-2 cursor-pointer transition-colors ${
                      form.price_type === opt.value
                        ? 'border-primary-500 bg-primary-50 text-primary-700'
                        : 'border-neutral-200 bg-white text-neutral-600 hover:border-neutral-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="price_type"
                      value={opt.value}
                      checked={form.price_type === opt.value}
                      onChange={(e) => setForm({ ...form, price_type: e.target.value })}
                      className="sr-only"
                    />
                    <span className="text-sm font-medium">{opt.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {form.price_type === 'fixed' && (
              <div>
                <label className="block text-sm font-medium text-neutral-700 mb-1">Цена</label>
                <input
                  type="number"
                  value={form.price_fixed}
                  onChange={(e) => setForm({ ...form, price_fixed: e.target.value })}
                  placeholder="2 500"
                  className="input"
                />
              </div>
            )}

            {form.price_type === 'range' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">От</label>
                  <input
                    type="number"
                    value={form.price_min}
                    onChange={(e) => setForm({ ...form, price_min: e.target.value })}
                    placeholder="1 500"
                    className="input"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1">До</label>
                  <input
                    type="number"
                    value={form.price_max}
                    onChange={(e) => setForm({ ...form, price_max: e.target.value })}
                    placeholder="5 000"
                    className="input"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Время выполнения</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Длительность, мин *</label>
              <input
                type="number"
                value={form.duration_minutes}
                onChange={(e) => setForm({ ...form, duration_minutes: parseInt(e.target.value) || 0 })}
                min={15}
                step={15}
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Мастеров параллельно</label>
              <input
                type="number"
                value={form.slot_size}
                onChange={(e) => setForm({ ...form, slot_size: parseInt(e.target.value) || 1 })}
                min={1}
                max={5}
                className="input"
              />
              <p className="text-xs text-neutral-400 mt-1">Сколько мастеров могут выполнять услугу одновременно</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button type="submit" disabled={saving} className="btn-primary btn-lg">
            <Save className="w-4 h-4" />
            {saving ? 'Сохранение...' : 'Добавить услугу'}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary btn-lg">
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
