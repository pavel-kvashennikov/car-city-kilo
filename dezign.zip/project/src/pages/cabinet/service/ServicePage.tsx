import { Link } from 'react-router-dom';
import { Plus, Edit, Trash2, Wrench } from 'lucide-react';
import { serviceProfiles } from '../../../data';

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

const priceTypeLabels: Record<string, string> = {
  fixed: 'Фиксированная',
  hourly: 'По нормо-часам',
  range: 'Диапазон',
  by_agreement: 'По договорённости',
};

export default function ServicePage() {
  const profile = serviceProfiles[0];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Сервис</h1>
        <Link to="/cabinet/service/add" className="btn-primary">
          <Plus className="w-4 h-4" />
          Добавить услугу
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="card p-4">
          <p className="text-2xl font-bold text-neutral-900">{profile?.services.length || 0}</p>
          <p className="text-sm text-neutral-500">Услуг</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-primary-600">{profile?.masters.length || 0}</p>
          <p className="text-sm text-neutral-500">Мастеров</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-accent-500">4.7</p>
          <p className="text-sm text-neutral-500">Рейтинг</p>
        </div>
      </div>

      <div className="card p-5">
        <h2 className="section-title mb-4">Прайс-лист</h2>
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100">
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Услуга</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Категория</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Тип цены</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Стоимость</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Время</th>
              <th className="w-20"></th>
            </tr>
          </thead>
          <tbody>
            {profile?.services.map((s) => (
              <tr key={s.id} className="border-b border-neutral-50 hover:bg-neutral-50/50 transition-colors">
                <td className="py-3">
                  <p className="text-sm font-medium text-neutral-900">{s.name}</p>
                  <p className="text-xs text-neutral-400 line-clamp-1">{s.description}</p>
                </td>
                <td className="py-3 text-sm text-neutral-600">{s.category.name}</td>
                <td className="py-3 text-sm text-neutral-600">{priceTypeLabels[s.price_type]}</td>
                <td className="py-3 text-sm font-semibold text-neutral-900">
                  {s.price_type === 'fixed' && s.price_fixed && formatPrice(s.price_fixed)}
                  {s.price_type === 'range' && s.price_min && s.price_max && `${formatPrice(s.price_min)} — ${formatPrice(s.price_max)}`}
                  {s.price_type === 'by_agreement' && 'По договорённости'}
                </td>
                <td className="py-3 text-sm text-neutral-600">{s.duration_minutes} мин</td>
                <td className="py-3">
                  <div className="flex items-center gap-1">
                    <button className="btn-ghost btn-icon"><Edit className="w-4 h-4" /></button>
                    <button className="btn-ghost btn-icon text-red-400"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card p-5">
        <h2 className="section-title mb-4">Мастера</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {profile?.masters.map((m) => (
            <div key={m.id} className="flex items-center gap-3 p-3 bg-neutral-50 rounded-lg">
              <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center">
                <Wrench className="w-4 h-4 text-primary-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-neutral-900">{m.name}</p>
                <p className="text-xs text-neutral-500">{m.specialization}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
