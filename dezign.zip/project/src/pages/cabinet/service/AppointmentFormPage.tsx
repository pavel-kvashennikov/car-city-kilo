import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, User, Car, Calendar, Clock, Wrench } from 'lucide-react';
import { serviceProfiles } from '../../../data';

export default function AppointmentFormPage() {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const profile = serviceProfiles[0];

  const [form, setForm] = useState({
    client_name: '',
    client_phone: '',
    service_id: '',
    master_id: '',
    date: '',
    time: '',
    vehicle_info: '',
    notes: '',
  });

  const times = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await new Promise((r) => setTimeout(r, 1000));
    navigate('/cabinet/service/schedule');
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-3xl">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="btn-ghost btn-icon">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="page-title">Новая запись</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-5">
          <h2 className="section-title mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-primary-500" />
            Клиент
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Имя *</label>
              <input
                type="text"
                value={form.client_name}
                onChange={(e) => setForm({ ...form, client_name: e.target.value })}
                placeholder="Иванов Иван"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Телефон *</label>
              <input
                type="tel"
                value={form.client_phone}
                onChange={(e) => setForm({ ...form, client_phone: e.target.value })}
                placeholder="+7 (999) 123-45-67"
                required
                className="input"
              />
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4 flex items-center gap-2">
            <Car className="w-5 h-5 text-primary-500" />
            Автомобиль
          </h2>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">Информация об авто</label>
            <input
              type="text"
              value={form.vehicle_info}
              onChange={(e) => setForm({ ...form, vehicle_info: e.target.value })}
              placeholder="Toyota Camry 2020, гос. А123ВС 77"
              className="input"
            />
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4 flex items-center gap-2">
            <Wrench className="w-5 h-5 text-primary-500" />
            Услуга
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Услуга *</label>
              <select
                value={form.service_id}
                onChange={(e) => setForm({ ...form, service_id: e.target.value })}
                required
                className="select"
              >
                <option value="">Выберите услугу</option>
                {profile?.services.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Мастер</label>
              <select
                value={form.master_id}
                onChange={(e) => setForm({ ...form, master_id: e.target.value })}
                className="select"
              >
                <option value="">Любой свободный</option>
                {profile?.masters.map((m) => (
                  <option key={m.id} value={m.id}>{m.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary-500" />
            Дата и время
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Дата *</label>
              <input
                type="date"
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
                min={new Date().toISOString().split('T')[0]}
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Время *</label>
              <select
                value={form.time}
                onChange={(e) => setForm({ ...form, time: e.target.value })}
                required
                className="select"
              >
                <option value="">Выберите время</option>
                {times.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Примечание</h2>
          <textarea
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            rows={3}
            placeholder="Дополнительная информация для мастера..."
            className="input"
          />
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button type="submit" disabled={saving} className="btn-primary btn-lg">
            <Save className="w-4 h-4" />
            {saving ? 'Сохранение...' : 'Записать'}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary btn-lg">
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
