import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Clock, User, X, Plus } from 'lucide-react';
import { serviceProfiles } from '../../../data';
import { useState } from 'react';

const days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const hours = Array.from({ length: 12 }, (_, i) => `${String(i + 8).padStart(2, '0')}:00`);

const appointments = [
  { id: 1, time: '09:00', duration: 60, client: 'Смирнов Иван', service: 'Замена масла', master: 'Иванов Алексей', status: 'confirmed' },
  { id: 2, time: '10:00', duration: 60, client: 'Козлова Мария', service: 'Диагностика', master: 'Иванов Алексей', status: 'pending' },
  { id: 3, time: '11:00', duration: 120, client: 'Петров Алексей', service: 'Замена колодок', master: 'Петров Дмитрий', status: 'in_progress' },
  { id: 4, time: '14:00', duration: 60, client: 'Федорова Анна', service: 'Сход-развал', master: 'Петров Дмитрий', status: 'confirmed' },
];

export default function SchedulePage() {
  const [selectedDay, setSelectedDay] = useState(new Date().getDay() || 7);
  const profile = serviceProfiles[0];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Расписание</h1>
        <div className="flex gap-2">
          <button className="btn-secondary"><X className="w-4 h-4" />Слот</button>
          <Link to="/cabinet/service/schedule/add" className="btn-primary"><Plus className="w-4 h-4" />Новая запись</Link>
        </div>
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <button className="btn-ghost btn-icon"><ChevronLeft className="w-5 h-5" /></button>
          <h2 className="text-base font-bold text-neutral-900">Март 2025</h2>
          <button className="btn-ghost btn-icon"><ChevronRight className="w-5 h-5" /></button>
        </div>

        <div className="flex gap-2 mb-6 overflow-x-auto scrollbar-hide">
          {Array.from({ length: 7 }, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() + i);
            const dayNum = d.getDate();
            const dayName = days[(d.getDay() + 6) % 7];
            const isToday = i === 0;
            return (
              <button
                key={i}
                onClick={() => setSelectedDay(i + 1)}
                className={`shrink-0 w-14 h-16 rounded-lg flex flex-col items-center justify-center gap-0.5 transition-colors ${
                  isToday ? 'bg-primary-600 text-white' : 'bg-neutral-50 text-neutral-700 hover:bg-neutral-100'
                }`}
              >
                <span className="text-xs font-medium">{dayName}</span>
                <span className="text-lg font-bold">{dayNum}</span>
              </button>
            );
          })}
        </div>

        <div className="space-y-2">
          {hours.map((hour) => {
            const appt = appointments.find(a => a.time === hour);
            return (
              <div key={hour} className="flex items-start gap-4 min-h-[3.5rem]">
                <span className="text-sm text-neutral-400 w-14 shrink-0 pt-1">{hour}</span>
                {appt ? (
                  <div className={`flex-1 rounded-lg p-3 border ${
                    appt.status === 'confirmed' ? 'bg-primary-50 border-primary-200' :
                    appt.status === 'in_progress' ? 'bg-accent-50 border-accent-200' :
                    'bg-warning-50 border-warning-200'
                  }`}>
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-neutral-900">{appt.service}</p>
                      <span className={`badge ${
                        appt.status === 'confirmed' ? 'badge-primary' :
                        appt.status === 'in_progress' ? 'badge-accent' :
                        'badge-warning'
                      }`}>
                        {appt.status === 'confirmed' ? 'Подтверждено' : appt.status === 'in_progress' ? 'В процессе' : 'Ожидает'}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 text-xs text-neutral-500">
                      <span className="flex items-center gap-1"><User className="w-3 h-3" />{appt.client}</span>
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{appt.duration} мин</span>
                    </div>
                    <p className="text-xs text-neutral-400 mt-0.5">Мастер: {appt.master}</p>
                  </div>
                ) : (
                  <div className="flex-1 border-t border-dashed border-neutral-200 pt-1">
                    <span className="text-xs text-neutral-300">Свободно</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
