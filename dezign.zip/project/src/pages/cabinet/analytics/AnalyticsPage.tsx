import { TrendingUp, Eye, Heart, ShoppingCart, BarChart3, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { dashboardStats } from '../../../data';

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

const weeklyViews = [120, 180, 95, 210, 165, 342, 0];
const maxView = Math.max(...weeklyViews);
const days = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];

const topVehicles = [
  { name: 'Toyota Camry 2023', views: 2100, leads: 12 },
  { name: 'BMW X5 2021', views: 1245, leads: 8 },
  { name: 'Kia K5 2024', views: 890, leads: 5 },
  { name: 'VW Tiguan 2020', views: 760, leads: 3 },
  { name: 'Hyundai Tucson 2023', views: 650, leads: 2 },
];

export default function AnalyticsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="page-title">Аналитика</h1>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <div className="flex items-center justify-between mb-2">
            <Eye className="w-5 h-5 text-primary-500" />
            <span className="flex items-center gap-0.5 text-xs text-green-600 font-medium"><ArrowUpRight className="w-3 h-3" />+12%</span>
          </div>
          <p className="text-2xl font-bold text-neutral-900">{dashboardStats.views_today}</p>
          <p className="text-sm text-neutral-500">Просмотров сегодня</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center justify-between mb-2">
            <Heart className="w-5 h-5 text-red-400" />
            <span className="flex items-center gap-0.5 text-xs text-green-600 font-medium"><ArrowUpRight className="w-3 h-3" />+8%</span>
          </div>
          <p className="text-2xl font-bold text-neutral-900">156</p>
          <p className="text-sm text-neutral-500">В избранном</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center justify-between mb-2">
            <ShoppingCart className="w-5 h-5 text-accent-500" />
            <span className="flex items-center gap-0.5 text-xs text-green-600 font-medium"><ArrowUpRight className="w-3 h-3" />+5%</span>
          </div>
          <p className="text-2xl font-bold text-neutral-900">{dashboardStats.leads_count}</p>
          <p className="text-sm text-neutral-500">Заявок всего</p>
        </div>
        <div className="card p-4">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-5 h-5 text-accent-500" />
            <span className="flex items-center gap-0.5 text-xs text-green-600 font-medium"><ArrowUpRight className="w-3 h-3" />+18%</span>
          </div>
          <p className="text-2xl font-bold text-neutral-900">{formatPrice(dashboardStats.revenue)}</p>
          <p className="text-sm text-neutral-500">Выручка</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h2 className="section-title mb-4">Просмотры за неделю</h2>
          <div className="flex items-end gap-3 h-40">
            {weeklyViews.map((v, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div
                  className="w-full rounded-t-md bg-primary-500 transition-all hover:bg-primary-400"
                  style={{ height: `${maxView > 0 ? (v / maxView) * 100 : 0}%`, minHeight: v > 0 ? '4px' : '0' }}
                />
                <span className="text-xs text-neutral-400">{days[i]}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Конверсия заявок</h2>
          <div className="flex items-center justify-center gap-8 py-6">
            <div className="text-center">
              <p className="text-3xl font-bold text-primary-600">8.2%</p>
              <p className="text-sm text-neutral-500">Заявки/Просмотры</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-bold text-accent-500">34%</p>
              <p className="text-sm text-neutral-500">Заявки/Продажи</p>
            </div>
          </div>
        </div>
      </div>

      <div className="card p-5">
        <h2 className="section-title mb-4">ТОП автомобилей по просмотрам</h2>
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100">
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">#</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Автомобиль</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Просмотры</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Заявки</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Конверсия</th>
            </tr>
          </thead>
          <tbody>
            {topVehicles.map((v, i) => (
              <tr key={i} className="border-b border-neutral-50">
                <td className="py-3 text-sm text-neutral-400">{i + 1}</td>
                <td className="py-3 text-sm font-medium text-neutral-900">{v.name}</td>
                <td className="py-3 text-sm text-neutral-600">{v.views.toLocaleString('ru-RU')}</td>
                <td className="py-3 text-sm text-neutral-600">{v.leads}</td>
                <td className="py-3 text-sm font-semibold text-primary-600">{((v.leads / v.views) * 100).toFixed(1)}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
