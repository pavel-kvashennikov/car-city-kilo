import { Link } from 'react-router-dom';
import { Plus, Eye, Heart, Edit, Trash2, MoreHorizontal, Car, CheckCircle, Clock, XCircle } from 'lucide-react';
import { vehicles } from '../../../data';

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

const statusConfig: Record<string, { label: string; className: string }> = {
  active: { label: 'Активно', className: 'badge-success' },
  pending: { label: 'На модерации', className: 'badge-warning' },
  draft: { label: 'Черновик', className: 'badge-neutral' },
  sold: { label: 'Продано', className: 'badge-primary' },
  archived: { label: 'В архиве', className: 'badge-neutral' },
};

export default function DealerVehicles() {
  const myVehicles = vehicles.filter((v) => v.dealer.slug === 'auto-prestige');

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Автомобили</h1>
        <Link to="/cabinet/dealer/add" className="btn-primary">
          <Plus className="w-4 h-4" />
          Добавить объявление
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <p className="text-2xl font-bold text-neutral-900">{myVehicles.length}</p>
          <p className="text-sm text-neutral-500">Всего</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-accent-500">{myVehicles.filter(v => v.status === 'active').length}</p>
          <p className="text-sm text-neutral-500">Активных</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-warning-500">{myVehicles.filter(v => v.status === 'pending').length}</p>
          <p className="text-sm text-neutral-500">На модерации</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-neutral-400">{myVehicles.filter(v => v.status === 'draft').length}</p>
          <p className="text-sm text-neutral-500">Черновиков</p>
        </div>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100 bg-neutral-50">
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Автомобиль</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Цена</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Статус</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Просмотры</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Избранное</th>
              <th className="w-24"></th>
            </tr>
          </thead>
          <tbody>
            {myVehicles.map((v) => {
              const st = statusConfig[v.status] || statusConfig.draft;
              return (
                <tr key={v.id} className="border-b border-neutral-50 hover:bg-neutral-50/50 transition-colors">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <img src={v.cover_photo} alt="" className="w-16 h-11 rounded-lg object-cover bg-neutral-200" />
                      <div>
                        <p className="text-sm font-medium text-neutral-900">
                          {v.year} {v.brand.name} {v.model.name}
                        </p>
                        <p className="text-xs text-neutral-500">
                          {v.mileage} км, {v.engine_type} {v.engine_volume}L
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4 text-sm font-semibold text-neutral-900">{formatPrice(v.price)}</td>
                  <td className="px-5 py-4"><span className={st.className}>{st.label}</span></td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1 text-sm text-neutral-600">
                      <Eye className="w-3.5 h-3.5" /> {v.views_count}
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1 text-sm text-neutral-600">
                      <Heart className="w-3.5 h-3.5" /> {v.favorites_count}
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1">
                      <Link to={`/cars/${v.slug}`} className="btn-ghost btn-icon" title="Просмотр">
                        <Eye className="w-4 h-4" />
                      </Link>
                      <button className="btn-ghost btn-icon" title="Редактировать">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="btn-ghost btn-icon text-red-400 hover:text-red-600" title="Удалить">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {myVehicles.length === 0 && (
              <tr>
                <td colSpan={6} className="px-5 py-12 text-center">
                  <Car className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">Нет автомобилей</p>
                  <button className="btn-primary mt-3">Добавить первый автомобиль</button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
