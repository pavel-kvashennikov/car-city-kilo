import { Bell, Phone, Mail, Clock, Car, CreditCard, ArrowLeftRight, MessageSquare } from 'lucide-react';
import { dealerLeads } from '../../../data';

const typeConfig: Record<string, { label: string; icon: typeof Bell; color: string }> = {
  test_drive: { label: 'Тест-драйв', icon: Car, color: 'badge-primary' },
  credit: { label: 'Кредит', icon: CreditCard, color: 'badge-accent' },
  trade_in: { label: 'Trade-in', icon: ArrowLeftRight, color: 'badge-warning' },
  callback: { label: 'Обратный звонок', icon: Phone, color: 'badge-neutral' },
};

const statusConfig: Record<string, { label: string; className: string }> = {
  new: { label: 'Новая', className: 'bg-primary-50 text-primary-700 border-primary-200' },
  in_progress: { label: 'В работе', className: 'bg-warning-50 text-warning-700 border-warning-200' },
  completed: { label: 'Завершена', className: 'bg-green-50 text-green-700 border-green-200' },
  cancelled: { label: 'Отменена', className: 'bg-neutral-100 text-neutral-500 border-neutral-200' },
};

export default function DealerLeads() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Заявки</h1>
        <div className="flex gap-2">
          <button className="btn-secondary btn-sm">Экспорт</button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <p className="text-2xl font-bold text-primary-600">{dealerLeads.filter(l => l.status === 'new').length}</p>
          <p className="text-sm text-neutral-500">Новых</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-warning-500">{dealerLeads.filter(l => l.status === 'in_progress').length}</p>
          <p className="text-sm text-neutral-500">В работе</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-green-600">{dealerLeads.filter(l => l.status === 'completed').length}</p>
          <p className="text-sm text-neutral-500">Завершено</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-neutral-400">{dealerLeads.length}</p>
          <p className="text-sm text-neutral-500">Всего</p>
        </div>
      </div>

      <div className="space-y-3">
        {dealerLeads.map((lead) => {
          const tc = typeConfig[lead.lead_type] || typeConfig.callback;
          const sc = statusConfig[lead.status] || statusConfig.new;
          const TypeIcon = tc.icon;
          return (
            <div key={lead.id} className="card p-5 hover:shadow-card-hover transition-shadow">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary-50 flex items-center justify-center shrink-0">
                    <TypeIcon className="w-5 h-5 text-primary-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={tc.color}>{tc.label}</span>
                      <span className={`badge border ${sc.className}`}>{sc.label}</span>
                    </div>
                    <p className="text-sm font-semibold text-neutral-900">{lead.contact_name}</p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-neutral-500">
                      <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{lead.contact_phone}</span>
                      {lead.preferred_datetime && (
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(lead.preferred_datetime).toLocaleString('ru-RU')}</span>
                      )}
                    </div>
                    {lead.vehicle && (
                      <p className="text-xs text-neutral-500 mt-1">
                        {lead.vehicle.year} {lead.vehicle.brand.name} {lead.vehicle.model.name}
                      </p>
                    )}
                    {lead.message && (
                      <p className="text-xs text-neutral-400 mt-2 flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" />{lead.message}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button className="btn-secondary btn-sm">В работу</button>
                  <button className="btn-primary btn-sm">Позвонить</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
