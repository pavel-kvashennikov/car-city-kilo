import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Upload, Plus, X } from 'lucide-react';
import { carBrands } from '../../../data';

export default function VehicleFormPage() {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    brand_id: '',
    model_name: '',
    year: new Date().getFullYear(),
    price: '',
    mileage: 0,
    condition: 'used',
    body_type: 'sedan',
    engine_type: 'petrol',
    engine_volume: '',
    engine_power: '',
    transmission: 'automatic',
    drive_type: 'fwd',
    color: '',
    vin: '',
    description: '',
    allows_test_drive: true,
    allows_credit: true,
    allows_trade_in: true,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await new Promise((r) => setTimeout(r, 1000));
    navigate('/cabinet/dealer');
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="btn-ghost btn-icon">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="page-title">Добавить автомобиль</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-5">
          <h2 className="section-title mb-4">Основная информация</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Марка *</label>
              <select
                value={form.brand_id}
                onChange={(e) => setForm({ ...form, brand_id: e.target.value })}
                required
                className="select"
              >
                <option value="">Выберите марку</option>
                {carBrands.map((b) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Модель *</label>
              <input
                type="text"
                value={form.model_name}
                onChange={(e) => setForm({ ...form, model_name: e.target.value })}
                placeholder="Camry"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Год *</label>
              <input
                type="number"
                value={form.year}
                onChange={(e) => setForm({ ...form, year: parseInt(e.target.value) })}
                min={1990}
                max={new Date().getFullYear() + 1}
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Цена *</label>
              <input
                type="number"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                placeholder="2 500 000"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Пробег, км</label>
              <input
                type="number"
                value={form.mileage}
                onChange={(e) => setForm({ ...form, mileage: parseInt(e.target.value) || 0 })}
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Состояние</label>
              <select
                value={form.condition}
                onChange={(e) => setForm({ ...form, condition: e.target.value })}
                className="select"
              >
                <option value="new">Новый</option>
                <option value="used">С пробегом</option>
              </select>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Технические характеристики</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Тип кузова</label>
              <select value={form.body_type} onChange={(e) => setForm({ ...form, body_type: e.target.value })} className="select">
                <option value="sedan">Седан</option>
                <option value="hatchback">Хэтчбек</option>
                <option value="wagon">Универсал</option>
                <option value="coupe">Купе</option>
                <option value="suv">Внедорожник</option>
                <option value="minivan">Минивэн</option>
                <option value="pickup">Пикап</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Двигатель</label>
              <select value={form.engine_type} onChange={(e) => setForm({ ...form, engine_type: e.target.value })} className="select">
                <option value="petrol">Бензин</option>
                <option value="diesel">Дизель</option>
                <option value="hybrid">Гибрид</option>
                <option value="electric">Электро</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Объём, л</label>
              <input
                type="text"
                value={form.engine_volume}
                onChange={(e) => setForm({ ...form, engine_volume: e.target.value })}
                placeholder="2.0"
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Мощность, л.с.</label>
              <input
                type="number"
                value={form.engine_power}
                onChange={(e) => setForm({ ...form, engine_power: e.target.value })}
                placeholder="150"
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">КПП</label>
              <select value={form.transmission} onChange={(e) => setForm({ ...form, transmission: e.target.value })} className="select">
                <option value="manual">МКПП</option>
                <option value="automatic">АКПП</option>
                <option value="robot">Робот</option>
                <option value="cvt">Вариатор</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Привод</label>
              <select value={form.drive_type} onChange={(e) => setForm({ ...form, drive_type: e.target.value })} className="select">
                <option value="fwd">Передний</option>
                <option value="rwd">Задний</option>
                <option value="awd">Полный</option>
                <option value="4wd">4WD</option>
              </select>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Дополнительно</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Цвет</label>
              <input
                type="text"
                value={form.color}
                onChange={(e) => setForm({ ...form, color: e.target.value })}
                placeholder="Белый"
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">VIN</label>
              <input
                type="text"
                value={form.vin}
                onChange={(e) => setForm({ ...form, vin: e.target.value.toUpperCase() })}
                placeholder="JTDKN3DU..."
                maxLength={17}
                className="input"
              />
            </div>
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-neutral-700 mb-1">Описание</label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={4}
              placeholder="Опишите автомобиль, его состояние, комплектацию..."
              className="input"
            />
          </div>
          <div className="mt-4 flex flex-wrap gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.allows_test_drive} onChange={(e) => setForm({ ...form, allows_test_drive: e.target.checked })} className="w-4 h-4 rounded" />
              <span className="text-sm text-neutral-700">Тест-драйв</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.allows_credit} onChange={(e) => setForm({ ...form, allows_credit: e.target.checked })} className="w-4 h-4 rounded" />
              <span className="text-sm text-neutral-700">Кредит</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.allows_trade_in} onChange={(e) => setForm({ ...form, allows_trade_in: e.target.checked })} className="w-4 h-4 rounded" />
              <span className="text-sm text-neutral-700">Trade-in</span>
            </label>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Фотографии</h2>
          <div className="border-2 border-dashed border-neutral-200 rounded-lg p-8 text-center hover:border-primary-400 transition-colors cursor-pointer">
            <Upload className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
            <p className="text-sm text-neutral-500">Перетащите фото или нажмите для выбора</p>
            <p className="text-xs text-neutral-400 mt-1">PNG, JPG до 10 МБ</p>
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button type="submit" disabled={saving} className="btn-primary btn-lg">
            <Save className="w-4 h-4" />
            {saving ? 'Сохранение...' : 'Опубликовать'}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary btn-lg">
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
