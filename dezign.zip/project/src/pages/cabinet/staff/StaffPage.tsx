import { Plus, User, Shield, Mail, MoreHorizontal } from 'lucide-react';

const staffMembers = [
  { id: 1, name: 'Иванов Иван', email: 'ivanov@autoprestige.ru', role: 'owner', profile: 'Все профили', status: 'active' },
  { id: 2, name: 'Петров Алексей', email: 'petrov@autoprestige.ru', role: 'sales_manager', profile: 'DealerProfile', status: 'active' },
  { id: 3, name: 'Сидорова Мария', email: 'sidorova@autoprestige.ru', role: 'storekeeper', profile: 'PartsProfile', status: 'active' },
  { id: 4, name: 'Козлов Дмитрий', email: 'kozlov@autoprestige.ru', role: 'service_advisor', profile: 'ServiceProfile', status: 'invited' },
];

const roleLabels: Record<string, string> = {
  owner: 'Владелец',
  sales_manager: 'Менеджер по продажам',
  storekeeper: 'Кладовщик',
  service_advisor: 'Мастер-консультант',
};

export default function StaffPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Сотрудники</h1>
        <button className="btn-primary">
          <Plus className="w-4 h-4" />
          Пригласить сотрудника
        </button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100 bg-neutral-50">
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Сотрудник</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Роль</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Профиль</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Статус</th>
              <th className="w-10"></th>
            </tr>
          </thead>
          <tbody>
            {staffMembers.map((member) => (
              <tr key={member.id} className="border-b border-neutral-50 hover:bg-neutral-50/50 transition-colors">
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-primary-100 flex items-center justify-center">
                      <User className="w-4 h-4 text-primary-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-neutral-900">{member.name}</p>
                      <p className="text-xs text-neutral-500">{member.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-4">
                  <span className="badge-primary">{roleLabels[member.role] || member.role}</span>
                </td>
                <td className="px-5 py-4 text-sm text-neutral-600">{member.profile}</td>
                <td className="px-5 py-4">
                  <span className={member.status === 'active' ? 'badge-success' : 'badge-warning'}>
                    {member.status === 'active' ? 'Активен' : 'Приглашён'}
                  </span>
                </td>
                <td className="px-5 py-4">
                  <button className="btn-ghost btn-icon">
                    <MoreHorizontal className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
