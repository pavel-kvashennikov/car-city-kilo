import { CreditCard, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { plans } from '../../../data';

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

const payments = [
  { id: 1, date: '2025-03-01', plan: 'Pro', amount: 14900, status: 'paid' },
  { id: 2, date: '2025-02-01', plan: 'Pro', amount: 14900, status: 'paid' },
  { id: 3, date: '2025-01-01', plan: 'Basic', amount: 4900, status: 'paid' },
];

export default function BillingPage() {
  const currentPlan = plans[1];

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="page-title">Биллинг</h1>

      <div className="card p-5 border-primary-200 bg-primary-50/30">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-neutral-500 mb-1">Текущий тариф</p>
            <h2 className="text-xl font-bold text-neutral-900">{currentPlan.name}</h2>
            <p className="text-sm text-primary-600 font-semibold mt-1">{formatPrice(currentPlan.price_monthly)}/мес</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-neutral-500 mb-1">Следующий платёж</p>
            <p className="text-sm font-medium text-neutral-900">1 апреля 2025</p>
            <span className="badge-success mt-1">Активна</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {plans.map((plan) => (
          <div key={plan.id} className={`card p-5 ${plan.slug === 'pro' ? 'ring-2 ring-primary-500' : ''}`}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-bold text-neutral-900">{plan.name}</h3>
              {plan.slug === 'pro' && <span className="badge-primary">Текущий</span>}
            </div>
            <p className="text-2xl font-bold text-primary-600 mb-1">{formatPrice(plan.price_monthly)}<span className="text-sm font-normal text-neutral-500">/мес</span></p>
            {plan.price_yearly && (
              <p className="text-sm text-neutral-500 mb-4">{formatPrice(plan.price_yearly)}/год (экономия 17%)</p>
            )}
            <ul className="space-y-2 mb-4">
              <li className="flex items-center gap-2 text-sm text-neutral-600">
                <CheckCircle className="w-4 h-4 text-accent-500 shrink-0" />
                {plan.features.max_vehicles ? `До ${plan.features.max_vehicles} авто` : 'Безлимит авто'}
              </li>
              <li className="flex items-center gap-2 text-sm text-neutral-600">
                <CheckCircle className="w-4 h-4 text-accent-500 shrink-0" />
                {plan.features.max_products ? `До ${plan.features.max_products} товаров` : 'Безлимит товаров'}
              </li>
              <li className="flex items-center gap-2 text-sm text-neutral-600">
                <CheckCircle className="w-4 h-4 text-accent-500 shrink-0" />
                {plan.features.auto_moderation ? 'Авто-модерация' : 'Ручная модерация'}
              </li>
            </ul>
            <button className={plan.slug === 'pro' ? 'btn-secondary w-full' : 'btn-primary w-full'}>
              {plan.slug === 'pro' ? 'Текущий тариф' : 'Сменить тариф'}
            </button>
          </div>
        ))}
      </div>

      <div className="card p-5">
        <h2 className="section-title mb-4">История платежей</h2>
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100">
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Дата</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Тариф</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Сумма</th>
              <th className="text-left py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Статус</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} className="border-b border-neutral-50">
                <td className="py-3 text-sm text-neutral-700">{p.date}</td>
                <td className="py-3 text-sm font-medium text-neutral-900">{p.plan}</td>
                <td className="py-3 text-sm font-semibold text-neutral-900">{formatPrice(p.amount)}</td>
                <td className="py-3"><span className="badge-success">Оплачено</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
