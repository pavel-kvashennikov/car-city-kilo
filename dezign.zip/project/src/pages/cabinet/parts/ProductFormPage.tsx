import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, Upload } from 'lucide-react';
import { partCategories } from '../../../data';

export default function ProductFormPage() {
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '',
    brand: '',
    article_number: '',
    oem_number: '',
    category_id: '',
    price_retail: '',
    price_wholesale: '',
    quantity: 1,
    in_stock: true,
    description: '',
    compatible_cars: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    await new Promise((r) => setTimeout(r, 1000));
    navigate('/cabinet/parts');
  };

  const [categories] = useState(partCategories);

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl">
      <div className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="btn-ghost btn-icon">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="page-title">Добавить запчасть</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="card p-5">
          <h2 className="section-title mb-4">Основная информация</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Название *</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Масло моторное Motul 8100 X-clean 5W-30"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Бренд *</label>
              <input
                type="text"
                value={form.brand}
                onChange={(e) => setForm({ ...form, brand: e.target.value })}
                placeholder="Motul"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Артикул *</label>
              <input
                type="text"
                value={form.article_number}
                onChange={(e) => setForm({ ...form, article_number: e.target.value.toUpperCase() })}
                placeholder="102870 8100"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">OEM номер</label>
              <input
                type="text"
                value={form.oem_number}
                onChange={(e) => setForm({ ...form, oem_number: e.target.value.toUpperCase() })}
                placeholder="OEM 04475-0L010"
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Категория *</label>
              <select
                value={form.category_id}
                onChange={(e) => setForm({ ...form, category_id: e.target.value })}
                required
                className="select"
              >
                <option value="">Выберите категорию</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Описание</label>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={3}
                placeholder="Подробное описание товара..."
                className="input"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-neutral-700 mb-1">Совместимость с автомобилями</label>
              <input
                type="text"
                value={form.compatible_cars}
                onChange={(e) => setForm({ ...form, compatible_cars: e.target.value })}
                placeholder="Toyota Camry 2018+, Kia K5 2020+, Hyundai Sonata..."
                className="input"
              />
            </div>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Цены и наличие</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Розничная цена *</label>
              <input
                type="number"
                value={form.price_retail}
                onChange={(e) => setForm({ ...form, price_retail: e.target.value })}
                placeholder="1 500"
                required
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Оптовая цена</label>
              <input
                type="number"
                value={form.price_wholesale}
                onChange={(e) => setForm({ ...form, price_wholesale: e.target.value })}
                placeholder="1 200"
                className="input"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">Количество *</label>
              <input
                type="number"
                value={form.quantity}
                onChange={(e) => setForm({ ...form, quantity: parseInt(e.target.value) || 0 })}
                min={0}
                required
                className="input"
              />
            </div>
          </div>
          <label className="flex items-center gap-2 cursor-pointer mt-4">
            <input
              type="checkbox"
              checked={form.in_stock}
              onChange={(e) => setForm({ ...form, in_stock: e.target.checked })}
              className="w-4 h-4 rounded"
            />
            <span className="text-sm text-neutral-700">В наличии</span>
          </label>
        </div>

        <div className="card p-5">
          <h2 className="section-title mb-4">Изображение</h2>
          <div className="border-2 border-dashed border-neutral-200 rounded-lg p-8 text-center hover:border-primary-400 transition-colors cursor-pointer">
            <Upload className="w-10 h-10 text-neutral-300 mx-auto mb-3" />
            <p className="text-sm text-neutral-500">Перетащите фото или нажмите для выбора</p>
            <p className="text-xs text-neutral-400 mt-1">PNG, JPG до 10 МБ</p>
          </div>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <button type="submit" disabled={saving} className="btn-primary btn-lg">
            <Save className="w-4 h-4" />
            {saving ? 'Сохранение...' : 'Добавить товар'}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary btn-lg">
            Отмена
          </button>
        </div>
      </form>
    </div>
  );
}
