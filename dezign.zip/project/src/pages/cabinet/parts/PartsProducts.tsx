import { Link } from 'react-router-dom';
import { Plus, Search, Upload, Edit, Trash2, Package, ShoppingCart } from 'lucide-react';
import { products } from '../../../data';

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

export default function PartsProducts() {
  const myProducts = products.filter((p) => p.store.slug === 'auto-detail');

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Запчасти</h1>
        <div className="flex gap-2">
          <button className="btn-secondary">
            <Upload className="w-4 h-4" />
            Импорт
          </button>
          <Link to="/cabinet/parts/add" className="btn-primary">
            <Plus className="w-4 h-4" />
            Добавить товар
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card p-4">
          <p className="text-2xl font-bold text-neutral-900">{myProducts.length}</p>
          <p className="text-sm text-neutral-500">Товаров</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-accent-500">{myProducts.filter(p => p.in_stock).length}</p>
          <p className="text-sm text-neutral-500">В наличии</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-warning-500">{myProducts.filter(p => !p.in_stock).length}</p>
          <p className="text-sm text-neutral-500">Нет в наличии</p>
        </div>
        <div className="card p-4">
          <p className="text-2xl font-bold text-primary-600">12</p>
          <p className="text-sm text-neutral-500">Заказов</p>
        </div>
      </div>

      <div className="card p-4 mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input placeholder="Поиск по названию, артикулу, OEM..." className="input pl-9" />
        </div>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100 bg-neutral-50">
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Товар</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Артикул / OEM</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Категория</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Цена</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Остаток</th>
              <th className="w-24"></th>
            </tr>
          </thead>
          <tbody>
            {myProducts.map((p) => (
              <tr key={p.id} className="border-b border-neutral-50 hover:bg-neutral-50/50 transition-colors">
                <td className="px-5 py-4">
                  <div className="flex items-center gap-3">
                    <img src={p.cover_photo} alt="" className="w-12 h-12 rounded-lg object-cover bg-neutral-200" />
                    <div>
                      <p className="text-sm font-medium text-neutral-900 line-clamp-1">{p.name}</p>
                      <p className="text-xs text-neutral-500">{p.brand}</p>
                    </div>
                  </div>
                </td>
                <td className="px-5 py-4">
                  <p className="text-sm text-neutral-700">{p.article_number}</p>
                  {p.oem_number && <p className="text-xs text-neutral-400">OEM: {p.oem_number}</p>}
                </td>
                <td className="px-5 py-4 text-sm text-neutral-600">{p.category.name}</td>
                <td className="px-5 py-4 text-sm font-semibold text-neutral-900">{formatPrice(p.price_retail)}</td>
                <td className="px-5 py-4">
                  <span className={p.in_stock ? 'badge-success' : 'badge-error'}>
                    {p.in_stock ? `${p.quantity} шт` : 'Нет'}
                  </span>
                </td>
                <td className="px-5 py-4">
                  <div className="flex items-center gap-1">
                    <button className="btn-ghost btn-icon" title="Редактировать">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="btn-ghost btn-icon text-red-400 hover:text-red-600" title="Удалить">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {myProducts.length === 0 && (
              <tr>
                <td colSpan={6} className="px-5 py-12 text-center">
                  <Package className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">Нет товаров</p>
                  <button className="btn-primary mt-3">Добавить первый товар</button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
