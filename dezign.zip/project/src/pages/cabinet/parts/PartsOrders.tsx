import { Package, Clock, CheckCircle, Truck, XCircle } from 'lucide-react';

const orders = [
  { id: 1, number: 'ORD-2025-00042', customer: 'Смирнов Иван', items: 3, total: 7150, status: 'new', date: '2025-03-19' },
  { id: 2, number: 'ORD-2025-00041', customer: 'Козлова Мария', items: 1, total: 3200, status: 'confirmed', date: '2025-03-18' },
  { id: 3, number: 'ORD-2025-00040', customer: 'Петров Алексей', items: 5, total: 12500, status: 'ready', date: '2025-03-17' },
  { id: 4, number: 'ORD-2025-00039', customer: 'Федорова Анна', items: 2, total: 8400, status: 'completed', date: '2025-03-16' },
];

const statusConfig: Record<string, { label: string; className: string; icon: typeof Clock }> = {
  new: { label: 'Новый', className: 'bg-primary-50 text-primary-700', icon: Clock },
  confirmed: { label: 'Подтверждён', className: 'bg-warning-50 text-warning-700', icon: CheckCircle },
  ready: { label: 'Готов к выдаче', className: 'bg-accent-50 text-accent-700', icon: Truck },
  completed: { label: 'Выдан', className: 'bg-green-50 text-green-700', icon: CheckCircle },
  cancelled: { label: 'Отменён', className: 'bg-neutral-100 text-neutral-500', icon: XCircle },
};

function formatPrice(price: number) {
  return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
}

export default function PartsOrders() {
  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="page-title">Заказы запчастей</h1>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {Object.entries(statusConfig).map(([key, cfg]) => {
          const count = orders.filter(o => o.status === key).length;
          return (
            <div key={key} className="card p-4">
              <p className="text-2xl font-bold text-neutral-900">{count}</p>
              <p className="text-sm text-neutral-500">{cfg.label}</p>
            </div>
          );
        })}
      </div>

      <div className="card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-neutral-100 bg-neutral-50">
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Номер</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Покупатель</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Позиций</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Сумма</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Статус</th>
              <th className="text-left px-5 py-3 text-xs font-semibold text-neutral-500 uppercase tracking-wider">Дата</th>
              <th className="w-24"></th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => {
              const sc = statusConfig[order.status] || statusConfig.new;
              return (
                <tr key={order.id} className="border-b border-neutral-50 hover:bg-neutral-50/50 transition-colors">
                  <td className="px-5 py-4 text-sm font-medium text-primary-600">{order.number}</td>
                  <td className="px-5 py-4 text-sm text-neutral-900">{order.customer}</td>
                  <td className="px-5 py-4 text-sm text-neutral-600">{order.items} шт</td>
                  <td className="px-5 py-4 text-sm font-semibold text-neutral-900">{formatPrice(order.total)}</td>
                  <td className="px-5 py-4"><span className={`badge ${sc.className}`}>{sc.label}</span></td>
                  <td className="px-5 py-4 text-sm text-neutral-500">{order.date}</td>
                  <td className="px-5 py-4">
                    <button className="btn-secondary btn-sm">Подробнее</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
