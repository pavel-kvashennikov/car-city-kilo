import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Plus,
  TrendingUp,
  MessageSquare,
  ShoppingCart,
  Eye,
  Calendar,
  Phone,
  Clock,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';
import { dashboardStats, dealerLeads } from '../../data';

export default function CabinetDashboard() {
  const recentLeads = useMemo(() => dealerLeads.slice(0, 5), []);

  const getLeadTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      test_drive: 'Тест-драйв',
      credit: 'Кредит',
      trade_in: 'Обмен',
      callback: 'Обратный звонок',
    };
    return labels[type] || type;
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'new':
        return 'badge-primary';
      case 'in_progress':
        return 'badge-warning';
      case 'completed':
        return 'badge-success';
      default:
        return 'badge-neutral';
    }
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      new: 'Новая',
      in_progress: 'В работе',
      completed: 'Завершена',
    };
    return labels[status] || status;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('ru-RU').format(price) + ' ₽';

  const stats = [
    {
      label: 'Активные объявления',
      value: dashboardStats.active_vehicles,
      icon: TrendingUp,
      color: 'from-blue-50 to-blue-100',
      textColor: 'text-blue-600',
    },
    {
      label: 'Новые заявки',
      value: dashboardStats.new_leads_count,
      icon: MessageSquare,
      color: 'from-purple-50 to-purple-100',
      textColor: 'text-purple-600',
    },
    {
      label: 'Заказы',
      value: dashboardStats.orders_count,
      icon: ShoppingCart,
      color: 'from-green-50 to-green-100',
      textColor: 'text-green-600',
    },
    {
      label: 'Просмотры сегодня',
      value: dashboardStats.views_today,
      icon: Eye,
      color: 'from-orange-50 to-orange-100',
      textColor: 'text-orange-600',
    },
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="container-app py-8">
        <div className="mb-12">
          <h1 className="page-title mb-2">Добро пожаловать, Компания!</h1>
          <p className="text-neutral-600">Панель управления автодилером</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 mb-8">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div
                key={idx}
                className={`card p-6 bg-gradient-to-br ${stat.color} border-0`}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-sm text-neutral-700 font-medium mb-1">
                      {stat.label}
                    </p>
                    <p className={`text-3xl font-bold ${stat.textColor}`}>
                      {stat.value}
                    </p>
                  </div>
                  <Icon className={`h-8 w-8 ${stat.textColor} opacity-50`} />
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid gap-8 lg:grid-cols-3 mb-8">
          <div className="lg:col-span-2">
            <div className="card p-6">
              <h2 className="section-title mb-6">Быстрые действия</h2>

              <div className="grid gap-3 sm:grid-cols-3">
                <Link to="/cabinet/vehicles/new" className="btn btn-primary justify-center">
                  <Plus className="h-4 w-4" />
                  Добавить авто
                </Link>

                <Link to="/cabinet/products/new" className="btn btn-primary justify-center">
                  <Plus className="h-4 w-4" />
                  Добавить запчасть
                </Link>

                <Link to="/cabinet/schedule" className="btn btn-primary justify-center">
                  <Calendar className="h-4 w-4" />
                  Открыть расписание
                </Link>
              </div>
            </div>

            <div className="card p-6 mt-8">
              <h2 className="section-title mb-6">Последние заявки</h2>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-neutral-100">
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Тип
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Контакт
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Автомобиль
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Статус
                      </th>
                      <th className="text-left py-3 px-3 font-semibold text-neutral-700">
                        Дата
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentLeads.map((lead) => (
                      <tr
                        key={lead.id}
                        className="border-b border-neutral-100 hover:bg-neutral-50 transition-colors"
                      >
                        <td className="py-3 px-3">
                          <span className="text-neutral-900 font-medium">
                            {getLeadTypeLabel(lead.lead_type)}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <div>
                            <p className="text-neutral-900 font-medium">
                              {lead.contact_name}
                            </p>
                            <p className="text-xs text-neutral-600 flex items-center gap-1 mt-1">
                              <Phone className="h-3 w-3" />
                              {lead.contact_phone}
                            </p>
                          </div>
                        </td>
                        <td className="py-3 px-3">
                          <span className="text-neutral-900">
                            {lead.vehicle.brand.name} {lead.vehicle.model.name}
                          </span>
                        </td>
                        <td className="py-3 px-3">
                          <span className={`badge ${getStatusBadgeColor(lead.status)}`}>
                            {getStatusLabel(lead.status)}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-neutral-600 text-xs">
                          {formatDate(lead.created_at)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <Link
                to="/cabinet/leads"
                className="btn btn-secondary btn-sm mt-4"
              >
                Все заявки →
              </Link>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-8">
              <h2 className="section-title mb-6">Статистика</h2>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-primary-50 to-primary-100 rounded-lg">
                  <span className="text-sm text-neutral-700">Месячный доход</span>
                  <span className="font-bold text-primary-600">
                    {formatPrice(dashboardStats.revenue)}
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-neutral-600 font-medium mb-1">
                      Все объявления
                    </p>
                    <div className="w-full bg-neutral-200 rounded-full h-2">
                      <div
                        className="bg-primary-600 h-2 rounded-full"
                        style={{
                          width: `${(dashboardStats.active_vehicles / dashboardStats.vehicles_count) * 100}%`,
                        }}
                      />
                    </div>
                    <p className="text-xs text-neutral-600 mt-1">
                      {dashboardStats.active_vehicles} / {dashboardStats.vehicles_count}
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-neutral-600 font-medium mb-1">
                      Заявки на модерации
                    </p>
                    <div className="w-full bg-neutral-200 rounded-full h-2">
                      <div
                        className="bg-warning-500 h-2 rounded-full"
                        style={{ width: '30%' }}
                      />
                    </div>
                    <p className="text-xs text-neutral-600 mt-1">
                      3 / 10
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 border-t border-neutral-100 pt-6">
                <h3 className="font-semibold text-neutral-900 mb-3 flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-warning-600" />
                  Внимание
                </h3>
                <p className="text-sm text-neutral-600">
                  У вас осталось <strong>3 дня</strong> до окончания тарифа. Пожалуйста, продлите подписку.
                </p>
                <button className="btn btn-primary w-full mt-3">
                  Продлить план
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="card p-6">
          <h2 className="section-title mb-6">График доходов (примерно)</h2>

          <div className="flex items-end justify-center gap-2 h-48">
            {[65, 45, 80, 70, 85, 90, 75, 88, 92, 70, 85, 95].map((height, idx) => (
              <div
                key={idx}
                className="flex-1 bg-gradient-to-t from-primary-500 to-primary-300 rounded-t-lg hover:opacity-75 transition-opacity cursor-pointer"
                style={{ height: `${height}%` }}
                title={`${height}k ₽`}
              />
            ))}
          </div>

          <div className="mt-4 flex items-center justify-center gap-6 text-sm">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded bg-primary-500" />
              <span className="text-neutral-600">Доход за период</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
