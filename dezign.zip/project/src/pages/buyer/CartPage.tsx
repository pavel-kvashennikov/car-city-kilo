import { useState } from 'react';
import { Trash2, Plus, Minus, Truck, MapPin } from 'lucide-react';

interface CartItem {
  id: number;
  productId: number;
  name: string;
  article: string;
  price: number;
  quantity: number;
  image: string;
}

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 1,
      productId: 1,
      name: 'Фильтр масляный MANN-FILTER OC295',
      article: 'OC295',
      price: 750,
      quantity: 1,
      image: 'https://images.pexels.com/photos/1624811/pexels-photo-1624811.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: 2,
      productId: 2,
      name: 'Колодки тормозные передние BOSCH',
      article: 'BP0986462772',
      price: 3200,
      quantity: 2,
      image: 'https://images.pexels.com/photos/1624811/pexels-photo-1624811.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ]);

  const [deliveryMethod, setDeliveryMethod] = useState<'pickup' | 'delivery'>('pickup');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
  });

  const formatPrice = (price: number) =>
    new Intl.NumberFormat('ru-RU').format(price) + ' ₽';

  const updateQuantity = (id: number, delta: number) => {
    setCartItems((items) =>
      items.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.max(1, item.quantity + delta) }
          : item
      )
    );
  };

  const removeItem = (id: number) => {
    setCartItems((items) => items.filter((item) => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const deliveryFee = deliveryMethod === 'delivery' ? 500 : 0;
  const total = subtotal + deliveryFee;

  const isEmpty = cartItems.length === 0;

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="container-app py-8">
        <h1 className="page-title mb-8">Корзина</h1>

        {isEmpty ? (
          <div className="card p-12 text-center">
            <div className="mb-4 text-5xl">🛒</div>
            <h2 className="section-title mb-2">Ваша корзина пуста</h2>
            <p className="text-neutral-600 mb-6">
              Добавьте запчасти для автомобиля, чтобы оформить заказ
            </p>
            <a href="/parts" className="btn btn-primary">
              Перейти в каталог
            </a>
          </div>
        ) : (
          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="card p-4 flex gap-4">
                    <div className="h-24 w-24 flex-shrink-0 rounded-lg bg-neutral-200 overflow-hidden">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover"
                      />
                    </div>

                    <div className="flex-grow">
                      <h3 className="font-semibold text-neutral-900 mb-1">
                        {item.name}
                      </h3>
                      <p className="text-sm text-neutral-600 mb-3">
                        Артикул: {item.article}
                      </p>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="p-1 rounded-lg hover:bg-neutral-100 transition-colors"
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="h-4 w-4 text-neutral-600" />
                        </button>

                        <span className="w-8 text-center font-semibold text-neutral-900">
                          {item.quantity}
                        </span>

                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="p-1 rounded-lg hover:bg-neutral-100 transition-colors"
                        >
                          <Plus className="h-4 w-4 text-neutral-600" />
                        </button>

                        <div className="flex-grow" />

                        <p className="text-lg font-bold text-primary-600">
                          {formatPrice(item.price * item.quantity)}
                        </p>

                        <button
                          onClick={() => removeItem(item.id)}
                          className="p-2 rounded-lg hover:bg-error-50 text-error-600 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="card p-6 mt-8">
                <h3 className="section-title mb-4">Добавить услугу установки</h3>
                <p className="text-neutral-600 mb-4">
                  Рекомендуемые сервисы для деталей в корзине:
                </p>

                <div className="space-y-2">
                  {[
                    { id: 1, name: 'Замена масла и масляного фильтра', price: 1500 },
                    { id: 2, name: 'Замена тормозных колодок (1 ось)', price: 3500 },
                    { id: 3, name: 'Компьютерная диагностика', price: 2500 },
                  ].map((service) => (
                    <button
                      key={service.id}
                      className="card p-3 w-full text-left hover:bg-primary-50 transition-colors border border-neutral-150 hover:border-primary-300"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-neutral-900">
                          {service.name}
                        </span>
                        <span className="font-bold text-primary-600">
                          {formatPrice(service.price)}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="card sticky top-8 p-6 space-y-6">
                <div>
                  <h3 className="section-title mb-4">Оформление заказа</h3>

                  <div className="space-y-2 pb-4 border-b border-neutral-100">
                    <div className="flex items-center justify-between text-neutral-700">
                      <span>Товары ({cartItems.length})</span>
                      <span className="font-semibold">{formatPrice(subtotal)}</span>
                    </div>

                    {deliveryMethod === 'delivery' && (
                      <div className="flex items-center justify-between text-neutral-700">
                        <span>Доставка</span>
                        <span className="font-semibold">{formatPrice(deliveryFee)}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-lg font-bold text-neutral-900 pt-2">
                      <span>Итого:</span>
                      <span className="text-primary-600">{formatPrice(total)}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-neutral-900 mb-3">Способ получения</h4>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 p-3 border border-neutral-200 rounded-lg cursor-pointer hover:bg-neutral-50 transition-colors" style={{ borderColor: deliveryMethod === 'pickup' ? '#2563eb' : '' }}>
                      <input
                        type="radio"
                        name="delivery"
                        value="pickup"
                        checked={deliveryMethod === 'pickup'}
                        onChange={() => setDeliveryMethod('pickup')}
                        className="accent-primary-600"
                      />
                      <MapPin className="h-4 w-4 text-neutral-600" />
                      <span className="text-sm font-medium text-neutral-900">
                        Самовывоз
                      </span>
                    </label>

                    <label className="flex items-center gap-3 p-3 border border-neutral-200 rounded-lg cursor-pointer hover:bg-neutral-50 transition-colors" style={{ borderColor: deliveryMethod === 'delivery' ? '#2563eb' : '' }}>
                      <input
                        type="radio"
                        name="delivery"
                        value="delivery"
                        checked={deliveryMethod === 'delivery'}
                        onChange={() => setDeliveryMethod('delivery')}
                        className="accent-primary-600"
                      />
                      <Truck className="h-4 w-4 text-neutral-600" />
                      <span className="text-sm font-medium text-neutral-900">
                        Доставка (+500 ₽)
                      </span>
                    </label>
                  </div>
                </div>

                <div className="space-y-3 border-t border-neutral-100 pt-6">
                  <div>
                    <label className="block text-sm font-medium text-neutral-900 mb-1">
                      Ваше имя
                    </label>
                    <input
                      type="text"
                      placeholder="Иван Сидоров"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, name: e.target.value }))
                      }
                      className="input"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-900 mb-1">
                      Телефон
                    </label>
                    <input
                      type="tel"
                      placeholder="+7 (999) 123-45-67"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, phone: e.target.value }))
                      }
                      className="input"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-neutral-900 mb-1">
                      Email
                    </label>
                    <input
                      type="email"
                      placeholder="ivan@example.com"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData((prev) => ({ ...prev, email: e.target.value }))
                      }
                      className="input"
                    />
                  </div>
                </div>

                <button className="btn-primary w-full justify-center py-3">
                  Оформить заказ
                </button>

                <button className="btn-secondary w-full justify-center">
                  Продолжить покупки
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
