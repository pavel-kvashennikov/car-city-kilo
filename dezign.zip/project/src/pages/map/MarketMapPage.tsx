import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import { marketZones, marketLocations } from '../../data';

interface TooltipState {
  id: number;
  x: number;
  y: number;
}

export default function MarketMapPage() {
  const [selectedTooltip, setSelectedTooltip] = useState<TooltipState | null>(null);

  const selectedLocation = useMemo(
    () => selectedTooltip ? marketLocations.find((l) => l.id === selectedTooltip.id) : null,
    [selectedTooltip]
  );

  const getLocationColor = (location: typeof marketLocations[0]) => {
    if (location.status === 'available') return '#d1d5db';
    if (location.status === 'reserved') return '#fbbf24';
    return location.zone.color;
  };

  const groupedByZone = useMemo(() => {
    const grouped: Record<number, typeof marketLocations> = {};
    marketLocations.forEach((loc) => {
      const zoneId = loc.zone.id;
      if (!grouped[zoneId]) grouped[zoneId] = [];
      grouped[zoneId].push(loc);
    });
    return grouped;
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="container-app py-8">
        <h1 className="page-title mb-2">Карта авторынка</h1>
        <p className="text-neutral-600 mb-8">
          Интерактивная карта размещения компаний на площади рынка
        </p>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="card p-6">
              <div className="mb-6 flex flex-wrap gap-2">
                {marketZones.map((zone) => (
                  <div key={zone.id} className="flex items-center gap-2 text-sm">
                    <div
                      className="h-4 w-4 rounded"
                      style={{ backgroundColor: zone.color }}
                    />
                    <span className="text-neutral-700">{zone.name}</span>
                  </div>
                ))}
                <div className="flex items-center gap-2 text-sm border-l border-neutral-200 pl-2">
                  <div className="h-4 w-4 rounded bg-gray-300" />
                  <span className="text-neutral-700">Свободно</span>
                </div>
                <div className="flex items-center gap-2 text-sm border-l border-neutral-200 pl-2">
                  <div className="h-4 w-4 rounded bg-yellow-400" />
                  <span className="text-neutral-700">Зарезервировано</span>
                </div>
              </div>

              <div className="relative w-full rounded-lg bg-gradient-to-b from-neutral-100 to-neutral-50 overflow-x-auto">
                <svg
                  viewBox="0 0 400 350"
                  className="w-full h-auto min-h-[500px] bg-white border border-neutral-200"
                >
                  <defs>
                    <pattern
                      id="grid"
                      width="40"
                      height="40"
                      patternUnits="userSpaceOnUse"
                    >
                      <path
                        d="M 40 0 L 0 0 0 40"
                        fill="none"
                        stroke="#e5e7eb"
                        strokeWidth="0.5"
                      />
                    </pattern>
                  </defs>

                  <rect width="400" height="350" fill="url(#grid)" />

                  {marketLocations.map((location) => (
                    <g
                      key={location.id}
                      onClick={() =>
                        setSelectedTooltip({
                          id: location.id,
                          x: location.coordinates.x + location.coordinates.width / 2,
                          y: location.coordinates.y - 10,
                        })
                      }
                      style={{ cursor: 'pointer' }}
                    >
                      <rect
                        x={location.coordinates.x}
                        y={location.coordinates.y}
                        width={location.coordinates.width}
                        height={location.coordinates.height}
                        fill={getLocationColor(location)}
                        stroke="#9ca3af"
                        strokeWidth="1"
                        rx="4"
                        opacity={0.8}
                        className="hover:opacity-100 transition-opacity"
                      />

                      <text
                        x={location.coordinates.x + location.coordinates.width / 2}
                        y={location.coordinates.y + location.coordinates.height / 2}
                        textAnchor="middle"
                        dominantBaseline="middle"
                        className="text-xs font-semibold fill-neutral-900 pointer-events-none"
                      >
                        {location.identifier}
                      </text>

                      {location.company && (
                        <text
                          x={location.coordinates.x + location.coordinates.width / 2}
                          y={location.coordinates.y + location.coordinates.height / 2 + 12}
                          textAnchor="middle"
                          dominantBaseline="middle"
                          className="text-xs fill-neutral-700 pointer-events-none"
                        >
                          {location.company.name.substring(0, 12)}
                        </text>
                      )}
                    </g>
                  ))}
                </svg>

                {selectedTooltip && selectedLocation && (
                  <div
                    className="absolute bg-white border border-neutral-200 rounded-lg shadow-lg p-4 w-64 z-10"
                    style={{
                      left: `${Math.min(selectedTooltip.x / 4, 320)}px`,
                      top: `${selectedTooltip.y / 3.5}px`,
                    }}
                  >
                    <button
                      onClick={() => setSelectedTooltip(null)}
                      className="absolute top-2 right-2 p-1 hover:bg-neutral-100 rounded transition-colors"
                    >
                      <X className="h-4 w-4" />
                    </button>

                    <p className="font-semibold text-neutral-900 mb-1">
                      {selectedLocation.identifier}
                    </p>

                    <p className="text-sm text-neutral-600 mb-2">
                      {selectedLocation.zone.name}
                    </p>

                    {selectedLocation.company && (
                      <>
                        <div className="mb-3 pb-3 border-b border-neutral-100">
                          <h4 className="font-semibold text-neutral-900 text-sm">
                            {selectedLocation.company.name}
                          </h4>
                          <p className="text-xs text-neutral-600 mt-1">
                            {selectedLocation.company.profile_types.join(', ')}
                          </p>
                        </div>

                        <Link
                          to={`/companies/${selectedLocation.company.slug}`}
                          className="btn btn-primary btn-sm w-full justify-center"
                        >
                          Перейти
                        </Link>
                      </>
                    )}

                    {selectedLocation.status === 'available' && (
                      <div className="text-sm text-success-600 font-medium">
                        ✓ Свободное место
                      </div>
                    )}

                    {selectedLocation.status === 'reserved' && (
                      <div className="text-sm text-warning-600 font-medium">
                        ⏳ Зарезервировано
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="card p-6">
              <h3 className="section-title mb-4">Местоположения</h3>

              <div className="space-y-6 max-h-[600px] overflow-y-auto">
                {marketZones.map((zone) => (
                  <div key={zone.id}>
                    <h4 className="font-semibold text-neutral-900 mb-2 flex items-center gap-2">
                      <div
                        className="h-3 w-3 rounded-sm"
                        style={{ backgroundColor: zone.color }}
                      />
                      {zone.name}
                    </h4>

                    <div className="space-y-2">
                      {groupedByZone[zone.id]?.map((location) => (
                        <button
                          key={location.id}
                          onClick={() =>
                            setSelectedTooltip({
                              id: location.id,
                              x: location.coordinates.x + location.coordinates.width / 2,
                              y: location.coordinates.y - 10,
                            })
                          }
                          className={`w-full text-left p-2 rounded-lg transition-all duration-200 ${
                            selectedTooltip?.id === location.id
                              ? 'bg-primary-50 border border-primary-300'
                              : 'bg-neutral-50 border border-neutral-150 hover:border-primary-300'
                          }`}
                        >
                          <p className="font-semibold text-sm text-neutral-900">
                            {location.identifier}
                          </p>

                          {location.company && (
                            <p className="text-xs text-neutral-600 mt-1">
                              {location.company.name}
                            </p>
                          )}

                          {location.status === 'available' && (
                            <p className="text-xs text-success-600 font-medium mt-1">
                              Свободно
                            </p>
                          )}

                          {location.status === 'reserved' && (
                            <p className="text-xs text-warning-600 font-medium mt-1">
                              Зарезервировано
                            </p>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
