import { BrowserRouter, Routes, Route } from 'react-router-dom';
import PublicLayout from './components/layout/PublicLayout';
import CabinetLayout from './components/layout/CabinetLayout';

import HomePage from './pages/home/HomePage';
import CarsIndex from './pages/catalog/CarsIndex';
import CarsShow from './pages/catalog/CarsShow';
import PartsIndex from './pages/catalog/PartsIndex';
import PartsShow from './pages/catalog/PartsShow';
import ServicesIndex from './pages/catalog/ServicesIndex';
import ServicesShow from './pages/catalog/ServicesShow';
import CompaniesIndex from './pages/companies/CompaniesIndex';
import CompaniesShow from './pages/companies/CompaniesShow';
import MarketMapPage from './pages/map/MarketMapPage';
import CartPage from './pages/buyer/CartPage';
import CabinetDashboard from './pages/cabinet/CabinetDashboard';
import CompanyPage from './pages/cabinet/company/CompanyPage';
import StaffPage from './pages/cabinet/staff/StaffPage';
import DealerVehicles from './pages/cabinet/dealer/DealerVehicles';
import DealerLeads from './pages/cabinet/dealer/DealerLeads';
import VehicleFormPage from './pages/cabinet/dealer/VehicleFormPage';
import PartsProducts from './pages/cabinet/parts/PartsProducts';
import PartsOrders from './pages/cabinet/parts/PartsOrders';
import ProductFormPage from './pages/cabinet/parts/ProductFormPage';
import ServicePage from './pages/cabinet/service/ServicePage';
import SchedulePage from './pages/cabinet/service/SchedulePage';
import ServiceFormPage from './pages/cabinet/service/ServiceFormPage';
import AppointmentFormPage from './pages/cabinet/service/AppointmentFormPage';
import BillingPage from './pages/cabinet/billing/BillingPage';
import AnalyticsPage from './pages/cabinet/analytics/AnalyticsPage';
import AdminDashboard from './pages/admin/AdminDashboard';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/cars" element={<CarsIndex />} />
          <Route path="/cars/:slug" element={<CarsShow />} />
          <Route path="/parts" element={<PartsIndex />} />
          <Route path="/parts/:slug" element={<PartsShow />} />
          <Route path="/services" element={<ServicesIndex />} />
          <Route path="/services/:slug" element={<ServicesShow />} />
          <Route path="/companies" element={<CompaniesIndex />} />
          <Route path="/companies/:slug" element={<CompaniesShow />} />
          <Route path="/map" element={<MarketMapPage />} />
          <Route path="/cart" element={<CartPage />} />
        </Route>

        <Route path="/cabinet" element={<CabinetLayout />}>
          <Route index element={<CabinetDashboard />} />
          <Route path="company" element={<CompanyPage />} />
          <Route path="staff" element={<StaffPage />} />
          <Route path="dealer" element={<DealerVehicles />} />
          <Route path="dealer/add" element={<VehicleFormPage />} />
          <Route path="dealer/:id/edit" element={<VehicleFormPage />} />
          <Route path="dealer/leads" element={<DealerLeads />} />
          <Route path="parts" element={<PartsProducts />} />
          <Route path="parts/add" element={<ProductFormPage />} />
          <Route path="parts/:id/edit" element={<ProductFormPage />} />
          <Route path="parts/orders" element={<PartsOrders />} />
          <Route path="service" element={<ServicePage />} />
          <Route path="service/add" element={<ServiceFormPage />} />
          <Route path="service/:id/edit" element={<ServiceFormPage />} />
          <Route path="service/schedule" element={<SchedulePage />} />
          <Route path="service/schedule/add" element={<AppointmentFormPage />} />
          <Route path="billing" element={<BillingPage />} />
          <Route path="analytics" element={<AnalyticsPage />} />
        </Route>

        <Route path="/admin" element={<CabinetLayout />}>
          <Route index element={<AdminDashboard />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
